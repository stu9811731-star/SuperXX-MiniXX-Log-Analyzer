import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeRecognizedNumber,adjustmentLabel,adjustedFuelValue,
  finalFuelValue,
  mergeRecognizedCells,getCurrentFuelValue,tokensToFuelCells,SCREENSHOT_RPM_AXIS,
  validateScreenshotFiles,MAX_SCREENSHOT_BYTES,repairRecognizedFuelValue
} from '../src/screenshot-map.js';

test('screenshot editor follows the supplied 800 RPM steps through 16000',()=>{
  assert.deepEqual(SCREENSHOT_RPM_AXIS,[800,1600,2400,3200,4000,4800,5600,6400,7200,8000,8800,9600,10400,11200,12000,12800,13600,14400,15200,16000]);
});

test('normalizes OCR number variants without inventing empty values',()=>{
  assert.equal(normalizeRecognizedNumber(' +100.8% '),100.8);
  assert.equal(normalizeRecognizedNumber('−1,6'),-1.6);
  assert.equal(normalizeRecognizedNumber('O.8'),0.8);
  assert.equal(normalizeRecognizedNumber('RPM'),null);
});

test('repairs a dropped fuel decimal and a context-supported leading 1',()=>{
  assert.deepEqual(repairRecognizedFuelValue(875,[93,100,94.5]),{value:87.5,repaired:true});
  assert.deepEqual(repairRecognizedFuelValue(1171,[87.5,93,100]),{value:117.1,repaired:true});
  assert.deepEqual(repairRecognizedFuelValue(17.1,[87.5,93,100]),{value:117.1,repaired:true});
  assert.deepEqual(repairRecognizedFuelValue(17.1,[15,20,25]),{value:17.1,repaired:false});
});

test('accepts only bounded JPG, PNG, and WEBP screenshot batches',()=>{
  const valid=[{name:'a.jpg',type:'image/jpeg',size:1024},{name:'b.webp',type:'image/webp',size:2048}];
  assert.deepEqual(validateScreenshotFiles(valid),valid);
  assert.throws(()=>validateScreenshotFiles([{name:'x.svg',type:'image/svg+xml',size:20}]),/JPG、PNG 或 WEBP/);
  assert.throws(()=>validateScreenshotFiles([{name:'huge.png',type:'image/png',size:MAX_SCREENSHOT_BYTES+1}]),/12 MB/);
  assert.throws(()=>validateScreenshotFiles(Array.from({length:9},(_,i)=>({name:`${i}.png`,type:'image/png',size:1}))),/最多 8 張/);
  assert.throws(()=>validateScreenshotFiles(Array.from({length:5},(_,i)=>({name:`${i}.png`,type:'image/png',size:10*1024*1024}))),/48 MB/);
});

test('labels add/remove fuel and computes final map value',()=>{
  assert.equal(adjustmentLabel(2.4),'加油 +2.4');
  assert.equal(adjustmentLabel(-1.6),'減油 -1.6');
  assert.equal(adjustmentLabel(0),'不需修改');
  assert.equal(adjustedFuelValue(100,2.4),102.4);
  assert.equal(adjustedFuelValue(98.4,-1.6),96.8);
  assert.equal(finalFuelValue(87.5,110),96.3);
  assert.equal(finalFuelValue(117.1,90),105.4);
  assert.equal(finalFuelValue(100,100),100);
});

test('maps OCR tokens by RPM and TPS headers',()=>{
  const vertical=[0,100,200,300];
  const horizontal=[0,60,120,180];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),token('1600',220,15),
    token('0',20,75),token('100',120,75),token('101.6',220,75),
    token('2',20,135),token('99.2',120,135),token('100',220,135)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({tps,rpm,value})=>({tps,rpm,value})),[
    {tps:0,rpm:800,value:100},{tps:0,rpm:1600,value:101.6},
    {tps:2,rpm:800,value:99.2},{tps:2,rpm:1600,value:100}
  ]);
});

test('keeps OCR fuel cells that lost 87.5 decimal or 117.1 leading digit',()=>{
  const vertical=[0,100,200,300,400,500];
  const horizontal=[0,60,120];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),token('1600',220,15),token('2400',320,15),token('3200',420,15),
    token('0',20,75),token('875',120,75),token('93.0',220,75),token('100',320,75),token('17.1',420,75)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({value,repaired})=>({value,repaired})),[
    {value:87.5,repaired:true},{value:93,repaired:false},{value:100,repaired:false},{value:117.1,repaired:true}
  ]);
  assert.equal(cells[0].confidence,60);
  assert.equal(cells[3].confidence,60);
});

test('infers blurred leading RPM headers from clear 800-step screenshot labels',()=>{
  const vertical=[0,100,200,300,400,500,600,700];
  const horizontal=[0,60,120];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('3200',420,15),token('4000',520,15),token('4800',620,15),
    token('0',20,75),
    token('94.5',120,75),token('93.0',220,75),token('77.3',320,75),
    token('80.5',420,75),token('80.5',520,75),token('80.5',620,75)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(cell=>cell.rpm),[800,1600,2400,3200,4000,4800]);
});

test('infers a blurred TPS label from its position in the ordered axis',()=>{
  const vertical=[0,100,200];
  const horizontal=[0,60,120,180,240];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),
    token('0',20,75),token('4',20,195),
    token('94.5',120,75),token('93.0',120,135),token('87.5',120,195)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({tps,value})=>({tps,value})),[
    {tps:0,value:94.5},{tps:2,value:93},{tps:4,value:87.5}
  ]);
});

test('merges overlapping screenshots and marks conflicting values',()=>{
  mergeRecognizedCells([{tps:10,rpm:3200,value:100,confidence:80,source:'a'}]);
  const result=mergeRecognizedCells([{tps:10,rpm:3200,value:100.8,confidence:90,source:'b'}]);
  assert.equal(result.conflicts,1);
  assert.equal(getCurrentFuelValue(10,3200),100.8);
});
