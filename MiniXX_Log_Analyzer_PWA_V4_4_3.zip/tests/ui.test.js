import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('primary page headers use the XXFueL brand',()=>{
  assert.match(read('index.html'),/<p class="eyebrow brandEyebrow">XXFueL<\/p>/);
  assert.match(read('compare.html'),/<p class="eyebrow brandEyebrow">XXFueL<\/p>/);
  assert.match(read('views.css'),/\.brandEyebrow \{ text-transform: none; \}/);
});

test('Fuel_CL UI exposes only include and exclude choices',()=>{
  const index=read('index.html');
  const select=index.match(/<select id="fuelClMode">([\s\S]*?)<\/select>/)?.[1]??'';
  assert.equal((select.match(/<option /g)??[]).length,2);
  assert.match(select,/不納入/);
  assert.match(select,/納入（MiniXX）/);
  assert.doesNotMatch(select,/positive_removes/);
  assert.match(select,/Fuel_CL 必須為 0/);
});

test('Log platform UI supports auto, Apple, and Android selection',()=>{
  const index=read('index.html');
  const compare=read('compare.html');
  for(const html of [index,compare]){
    assert.match(html,/自動辨識（建議）/);
    assert.match(html,/>Apple</);
    assert.match(html,/>Android MX App</);
    assert.match(html,/\.log/);
    assert.match(html,/\.csv/);
  }
});

test('advanced settings and result details are collapsed by default',()=>{
  const index=read('index.html');
  const compare=read('compare.html');
  assert.match(index,/<details class="advancedSettings">/);
  assert.match(index,/<details class="card resultDetails">/);
  assert.match(index,/id="minStable"[^>]+value="1"/);
  assert.match(index,/id="minSamples"/);
  assert.match(index,/20（預設）/);
  assert.match(compare,/id="compareMinStable"[^>]+value="1"/);
  assert.match(compare,/id="compareMinSamples"/);
  for(const title of ['解析診斷','資料品質 / 排除統計','異常與多 Log 一致性','點火角與壓力格位明細']){
    assert.match(index,new RegExp(`<summary><span>${title.replace('/','\\/')}<\\/span>`));
  }
  assert.doesNotMatch(index,/<details[^>]+open/);
});

test('ignition page can switch between actual angle and manifold pressure',()=>{
  const index=read('index.html');
  const app=read('src/app.js');
  assert.match(index,/id="ignitionMetric"/);
  assert.match(index,/點火角／進氣壓力/);
  assert.match(index,/實際點火角 °/);
  assert.match(index,/進氣歧管壓力（kPa abs）/);
  assert.match(index,/匯出點火／壓力 CSV/);
  assert.match(app,/pressureMode/);
  assert.match(app,/mapMedian/);
  assert.match(app,/缺少 Cyl1_Eng_AP／MAP 欄位/);
});

test('confidence legend uses requested high and medium colors and hides low suggestions',()=>{
  const index=read('index.html');
  const css=read('views.css');
  assert.match(index,/綠色：高可信度/);
  assert.match(index,/黃色：中可信度/);
  assert.match(index,/低可信度：不顯示建議/);
  assert.match(css,/\.map td\.confidence-high/);
  assert.match(css,/\.map td\.confidence-medium/);
  assert.match(css,/#mapWrap \.map td \{ padding: 4px 6px/);
});

test('before and after comparison uses the compact fuel map overview format',()=>{
  const compare=read('compare.html');
  const script=read('src/compare.js');
  const css=read('views.css');
  assert.match(compare,/id="compareDisplay"/);
  assert.match(compare,/綠色：改善/);
  assert.match(compare,/黃色：近似/);
  assert.match(compare,/橘色：惡化/);
  assert.match(compare,/灰色：單側／可信度不足/);
  assert.match(compare,/紅色：可能修過頭/);
  assert.match(script,/Overcorrected/);
  assert.match(script,/Low confidence/);
  assert.match(script,/function renderMap\(comparison\)/);
  assert.match(script,/resultLabel\[cell\.result\].*Math\.abs/);
  assert.doesNotMatch(script,/<small>前/);
  assert.match(css,/#compareMapWrap \.map td \{ padding: 4px 6px/);
  assert.match(css,/\.compareCell\.onlyOne/);
});

test('V4.4.2 safety band and extreme limit are explained in the primary UI',()=>{
  const index=read('index.html');
  assert.match(index,/±3% 內不修改/);
  assert.match(index,/達 11% 不直接修改/);
  assert.match(index,/最小 0\.8 步進/);
  assert.match(index,/開始 V4\.4\.2 分析/);
  assert.match(index,/id="baseFuelRange"/);
  assert.match(index,/id="baseFuel"/);
  assert.match(index,/最終供油＝全域燃油 × 基礎油量 ÷ 100/);
});

test('FAQ feedback fields and guide abbreviation table are present',()=>{
  const faq=read('faq.html');
  const guide=read('guide.html');
  assert.match(faq,/id="feedbackTitle"/);
  assert.match(faq,/id="feedbackMessage"/);
  assert.match(faq,/開啟問題回報頁/);
  for(const term of ['AFR','WBO2','Fuel_CL','TPS','RPM','T_Eng','FuelPW','Acc_Fuel_Mult','SA','Cyl1_Eng_AP','MAP']){
    assert.match(guide,new RegExp(term));
  }
});

test('content hub exposes eight original MiniXX guides and an honest about page',()=>{
  const hub=read('articles.html');
  const about=read('about.html');
  const articlePaths=[
    'articles/log-quality.html',
    'articles/afr-basics.html',
    'articles/fuel-cl.html',
    'articles/fuel-step-case.html',
    'articles/compare-logs.html',
    'articles/ignition-map.html',
    'articles/screenshot-map.html',
    'articles/troubleshooting.html'
  ];
  assert.equal((hub.match(/class="articleCard"/g)??[]).length,8);
  for(const path of articlePaths){
    const article=read(path);
    assert.match(article,/<meta name="description"/);
    assert.match(article,/<link rel="canonical" href="https:\/\/xxfuel\.com\/articles\//);
    assert.match(article,/XXFueL 編輯/);
    assert.match(article,/更新：2026-09-01/);
    assert.ok(article.length>1800,`${path} should contain substantial original guidance`);
  }
  assert.match(about,/我自己就是想玩 MiniXX/);
  assert.match(about,/並非 aRacer、MiniXX 或 SpeedTuningX 的官方產品/);
  assert.match(about,/id="contact"/);
});

test('public pages have crawl metadata, sitemap, and content navigation',()=>{
  for(const path of ['index.html','compare.html','guide.html','tuning.html','faq.html','privacy.html','articles.html','about.html']){
    const html=read(path);
    assert.match(html,/<meta name="description"/);
    assert.match(html,/<link rel="canonical" href="https:\/\/xxfuel\.com\//);
    assert.match(html,/教學文章/);
    assert.match(html,/關於本站/);
  }
  const sitemap=read('sitemap.xml');
  assert.equal((sitemap.match(/<url>/g)??[]).length,16);
  assert.match(sitemap,/articles\/troubleshooting\.html/);
  assert.match(read('robots.txt'),/Sitemap: https:\/\/xxfuel\.com\/sitemap\.xml/);
});

test('screenshot preview is local, optional, and requires confirmation',()=>{
  const index=read('index.html');
  const app=read('src/app.js');
  assert.match(index,/id="mapShots"[^>]+accept="image\/jpeg,image\/png,image\/webp"/);
  assert.match(index,/辨識結果確認/);
  assert.match(index,/沒有截圖仍可分析 Log/);
  assert.match(index,/tesseract\.min\.js/);
  assert.match(app,/adjustmentLabel/);
  assert.match(app,/全域.*最終供油/);
  assert.match(app,/空燃比差異.*afrResidualCorrectionPct/);
  assert.match(app,/實際.*目標/);
  assert.match(app,/c\.status!==\x27Adjust\x27/);
  assert.doesNotMatch(app,/未達建議門檻/);
  assert.doesNotMatch(app,/small>\$\{esc\(c\.confidence\)\}/);
});
