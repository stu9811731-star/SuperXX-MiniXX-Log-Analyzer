export const SCREENSHOT_RPM_AXIS = [800,1600,2400,3200,4000,4800,5600,6400,7200,8000,8800,9600,10400,11200,12000,12800,13600,14400,15200,16000];
export const SCREENSHOT_TPS_AXIS = [0,2,4,6,8,10,15,20,25,30,40,50,60,70,80,90,100];
export const MAX_SCREENSHOT_BYTES = 12 * 1024 * 1024;
export const MAX_SCREENSHOT_TOTAL_BYTES = 48 * 1024 * 1024;
export const MAX_SCREENSHOT_DIMENSION = 12000;
export const MAX_SCREENSHOT_PIXELS = 40000000;
const ALLOWED_SCREENSHOT_TYPES = new Set(['image/jpeg','image/png','image/webp']);

const currentFuelMap = new Map();
let ocrWorker = null;

export function normalizeRecognizedNumber(text) {
  const normalized=String(text??'')
    .replace(/[Oo]/g,'0')
    .replace(/[Il|]/g,'1')
    .replace(/[−–—]/g,'-')
    .replace(/,/g,'.')
    .replace(/%/g,'')
    .replace(/[^0-9+.-]/g,'');
  if(!normalized || !/[0-9]/.test(normalized)) return null;
  const value=Number(normalized);
  return Number.isFinite(value)?value:null;
}

function restoreDroppedDecimal(value){
  let next=Number(value),repaired=false;
  if(!Number.isFinite(next))return {value:null,repaired:false};
  // Fuel values in the MiniXX table are bounded to ±300. OCR frequently
  // drops the decimal point in values such as 87.5 -> 875 or 117.1 -> 1171.
  if(Math.abs(next)>300&&Math.abs(next)<=3000){next/=10;repaired=true;}
  return {value:next,repaired};
}

export function repairRecognizedFuelValue(value,referenceValues=[]){
  const restored=restoreDroppedDecimal(value);
  if(restored.value==null)return restored;
  let next=restored.value,repaired=restored.repaired;
  const references=referenceValues
    .map(item=>restoreDroppedDecimal(item).value)
    .filter(item=>Number.isFinite(item)&&item>=50&&item<=200)
    .sort((a,b)=>a-b);
  if(next>=10&&next<40&&references.length>=3){
    const middle=Math.floor(references.length/2);
    const typical=references.length%2?references[middle]:(references[middle-1]+references[middle])/2;
    const candidate=next+100;
    const originalGap=Math.abs(next-typical),candidateGap=Math.abs(candidate-typical);
    // A missing leading 1 is repaired only when the rest of the same
    // screenshot strongly supports a normal 50–200 fuel-map range.
    if(typical>=60&&typical<=160&&candidate<=200&&candidateGap<=45&&originalGap-candidateGap>=20){
      next=candidate;repaired=true;
    }
  }
  if(next < -200||next > 300)return {value:null,repaired};
  return {value:Number(next.toFixed(1)),repaired};
}

export function adjustmentLabel(value) {
  if(!Number.isFinite(value) || Math.abs(value)<0.05) return '不需修改';
  return value>0?`加油 +${value.toFixed(1)}`:`減油 ${value.toFixed(1)}`;
}

export function adjustedFuelValue(currentValue, adjustment) {
  if(!Number.isFinite(currentValue)||!Number.isFinite(adjustment)) return null;
  return Number((currentValue+adjustment).toFixed(1));
}

export function finalFuelValue(globalFuelValue, baseFuelPercent=100) {
  if(!Number.isFinite(globalFuelValue)||!Number.isFinite(baseFuelPercent)||baseFuelPercent<=0) return null;
  return Number((globalFuelValue*baseFuelPercent/100).toFixed(1));
}

export function validateScreenshotFiles(files) {
  const next=[...files];
  if(next.length>8)throw new Error('一次最多 8 張截圖。');
  for(const file of next){
    if(!ALLOWED_SCREENSHOT_TYPES.has(file.type))throw new Error('只接受 JPG、PNG 或 WEBP 圖片檔。');
    if(file.size>MAX_SCREENSHOT_BYTES)throw new Error(`${file.name} 超過 12 MB 上限。`);
  }
  if(next.reduce((total,file)=>total+file.size,0)>MAX_SCREENSHOT_TOTAL_BYTES)throw new Error('截圖總容量超過 48 MB 上限。');
  return next;
}

export function getCurrentFuelValue(tps,rpm) {
  const item=currentFuelMap.get(`${tps}|${rpm}`);
  return item&&Number.isFinite(item.value)?item.value:null;
}

export function getRecognizedFuelMap() {
  return new Map(currentFuelMap);
}

export function mergeRecognizedCells(cells) {
  let added=0,conflicts=0;
  for(const cell of cells){
    if(!SCREENSHOT_TPS_AXIS.includes(cell.tps)||!SCREENSHOT_RPM_AXIS.includes(cell.rpm)||!Number.isFinite(cell.value)) continue;
    const key=`${cell.tps}|${cell.rpm}`;
    const next={value:Number(cell.value),confidence:Number(cell.confidence)||0,source:cell.source||'',conflict:false,repaired:Boolean(cell.repaired),ocrValue:cell.ocrValue};
    const old=currentFuelMap.get(key);
    if(!old){currentFuelMap.set(key,next);added++;continue;}
    if(Math.abs(old.value-next.value)>0.05){
      conflicts++;
      if(next.confidence>=old.confidence) currentFuelMap.set(key,{...next,conflict:true});
      else currentFuelMap.set(key,{...old,conflict:true});
    }else if(next.confidence>old.confidence){currentFuelMap.set(key,next);}
  }
  return {added,conflicts,total:currentFuelMap.size};
}

function clusterIndexes(indexes,gap=2){
  const groups=[];
  for(const value of indexes){
    const last=groups.at(-1);
    if(!last||value-last.at(-1)>gap) groups.push([value]);
    else last.push(value);
  }
  return groups.map(group=>Math.round(group.reduce((a,b)=>a+b,0)/group.length));
}

function longestRun(flags,minLength=1){
  let best=null,start=null;
  for(let i=0;i<=flags.length;i++){
    if(i<flags.length&&flags[i]){if(start==null)start=i;continue;}
    if(start!=null){const run={start,end:i-1,length:i-start};if(run.length>=minLength&&(!best||run.length>best.length))best=run;start=null;}
  }
  return best;
}

function closeSmallGaps(flags,maxGap){
  const out=[...flags];
  let start=null;
  for(let i=0;i<=out.length;i++){
    if(i<out.length&&!out[i]){if(start==null)start=i;continue;}
    if(start!=null){
      const bounded=start>0&&i<out.length&&out[start-1]&&out[i];
      if(bounded&&i-start<=maxGap)for(let j=start;j<i;j++)out[j]=true;
      start=null;
    }
  }
  return out;
}

export function detectTableGeometry(imageData){
  const {data,width,height}=imageData;
  const lumaAt=(x,y)=>{const i=(y*width+x)*4;return data[i]*.299+data[i+1]*.587+data[i+2]*.114;};
  const brightRows=[];
  const xStep=Math.max(1,Math.floor(width/360));
  for(let y=0;y<height;y+=2){
    let bright=0,total=0;
    for(let x=0;x<width;x+=xStep){if(lumaAt(x,y)>105)bright++;total++;}
    brightRows[y]=bright/total>.48;
    brightRows[y+1]=brightRows[y];
  }
  const yRun=longestRun(closeSmallGaps(brightRows,10),Math.max(100,Math.floor(height*.12)));
  if(!yRun) throw new Error('找不到油量表格；請上傳包含完整表格邊線的原始截圖。');

  const brightCols=[];
  const yStep=Math.max(1,Math.floor(yRun.length/360));
  for(let x=0;x<width;x++){
    let bright=0,total=0;
    for(let y=yRun.start;y<=yRun.end;y+=yStep){if(lumaAt(x,y)>105)bright++;total++;}
    brightCols[x]=bright/total>.30;
  }
  const xRun=longestRun(closeSmallGaps(brightCols,10),Math.max(180,Math.floor(width*.45)));
  if(!xRun) throw new Error('找不到表格左右邊界；請勿裁掉 TPS 或 RPM 標題。');
  const bounds={left:Math.max(0,xRun.start-4),top:Math.max(0,yRun.start-4),right:Math.min(width-1,xRun.end+4),bottom:Math.min(height-1,yRun.end+4)};
  const tableWidth=bounds.right-bounds.left+1,tableHeight=bounds.bottom-bounds.top+1;

  const verticalCandidates=[];
  for(let x=bounds.left;x<=bounds.right;x++){
    let dark=0,total=0;
    for(let y=bounds.top;y<=bounds.bottom;y+=2){if(lumaAt(x,y)<82)dark++;total++;}
    if(dark/total>.48)verticalCandidates.push(x-bounds.left);
  }
  const horizontalCandidates=[];
  for(let y=bounds.top;y<=bounds.bottom;y++){
    let dark=0,total=0;
    for(let x=bounds.left;x<=bounds.right;x+=2){if(lumaAt(x,y)<82)dark++;total++;}
    if(dark/total>.48)horizontalCandidates.push(y-bounds.top);
  }
  let verticalLines=clusterIndexes(verticalCandidates,3);
  let horizontalLines=clusterIndexes(horizontalCandidates,3);
  const addEdges=(lines,max)=>{
    const out=[...lines];
    if(!out.length||out[0]>10)out.unshift(0);
    if(max-out.at(-1)>10)out.push(max);
    return out;
  };
  verticalLines=addEdges(verticalLines,tableWidth-1);
  horizontalLines=addEdges(horizontalLines,tableHeight-1);
  if(verticalLines.length<4||horizontalLines.length<4){
    throw new Error('表格格線辨識不足；請使用未壓縮、沒有塗畫且包含 RPM／TPS 標頭的截圖。');
  }
  return {bounds,verticalLines,horizontalLines};
}

function loadImage(file){
  return new Promise((resolve,reject)=>{
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{URL.revokeObjectURL(url);resolve(img);};
    img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error(`${file.name}: 圖片無法讀取`));};
    img.src=url;
  });
}

function prepareImage(img){
  if(img.naturalWidth>MAX_SCREENSHOT_DIMENSION||img.naturalHeight>MAX_SCREENSHOT_DIMENSION||img.naturalWidth*img.naturalHeight>MAX_SCREENSHOT_PIXELS){
    throw new Error(`圖片尺寸過大；寬高需在 ${MAX_SCREENSHOT_DIMENSION} 像素內，且總像素不得超過 40 MP。`);
  }
  const maxWidth=1400,maxHeight=2600;
  // Phone screenshots shared through messaging are often only ~590 px wide.
  // Upscale them before thresholding so decimal points and narrow leading 1s
  // remain large enough for OCR, while still respecting the existing cap.
  const scale=Math.min(2,maxWidth/img.naturalWidth,maxHeight/img.naturalHeight);
  const canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));
  canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  ctx.imageSmoothingEnabled=true;
  ctx.imageSmoothingQuality='high';
  ctx.drawImage(img,0,0,canvas.width,canvas.height);
  const source=ctx.getImageData(0,0,canvas.width,canvas.height);
  const geometry=detectTableGeometry(source);
  const {left,top,right,bottom}=geometry.bounds;
  const width=right-left+1,height=bottom-top+1;
  const raw=ctx.getImageData(left,top,width,height);
  const clean=document.createElement('canvas');
  clean.width=width;clean.height=height;
  const cleanCtx=clean.getContext('2d',{willReadFrequently:true});
  const pixels=raw.data;
  for(let i=0;i<pixels.length;i+=4){
    const luma=pixels[i]*.299+pixels[i+1]*.587+pixels[i+2]*.114;
    const value=luma<132?0:255;
    pixels[i]=pixels[i+1]=pixels[i+2]=value;pixels[i+3]=255;
  }
  cleanCtx.putImageData(raw,0,0);
  cleanCtx.fillStyle='#fff';
  for(const x of geometry.verticalLines)cleanCtx.fillRect(x-3,0,7,height);
  for(const y of geometry.horizontalLines)cleanCtx.fillRect(0,y-3,width,7);
  return {canvas:clean,geometry};
}

function parseTsv(tsv){
  const rows=String(tsv||'').split(/\r?\n/).slice(1),tokens=[];
  for(const row of rows){
    const parts=row.split('\t');
    if(parts.length<12||parts[0]!=='5')continue;
    const text=parts.slice(11).join('\t').trim();
    const value=normalizeRecognizedNumber(text);
    if(value==null)continue;
    tokens.push({text,value,left:Number(parts[6]),top:Number(parts[7]),width:Number(parts[8]),height:Number(parts[9]),confidence:Number(parts[10])||0});
  }
  return tokens;
}

function intervalIndex(value,lines){
  for(let i=0;i<lines.length-1;i++)if(value>lines[i]&&value<lines[i+1])return i;
  return -1;
}

export function tokensToFuelCells(tokens,verticalLines,horizontalLines,source='screenshot'){
  const buckets=new Map();
  for(const token of tokens){
    const col=intervalIndex(token.left+token.width/2,verticalLines);
    const row=intervalIndex(token.top+token.height/2,horizontalLines);
    if(row<0||col<0)continue;
    const key=`${row}|${col}`;
    if(!buckets.has(key))buckets.set(key,[]);
    buckets.get(key).push(token);
  }
  const cellValue=(row,col)=>{
    const pieces=(buckets.get(`${row}|${col}`)||[]).sort((a,b)=>a.left-b.left);
    if(!pieces.length)return null;
    const joined=pieces.map(x=>x.text).join('');
    return {value:normalizeRecognizedNumber(joined),confidence:pieces.reduce((a,b)=>a+b.confidence,0)/pieces.length};
  };
  const rpmForCol=new Map(),tpsForRow=new Map();
  for(let col=1;col<verticalLines.length-1;col++){
    const item=cellValue(0,col);
    if(item){const rpm=SCREENSHOT_RPM_AXIS.find(v=>Math.abs(v-item.value)<=5);if(rpm!=null)rpmForCol.set(col,rpm);}
  }
  // X Tune screenshots may omit or blur the first few RPM header labels. When
  // at least two labels are clear, infer the remaining visible columns from
  // their on-screen spacing, then accept only values that exist on the MiniXX
  // RPM axis. This fills labels; it never invents a fuel value.
  if(rpmForCol.size>=2){
    const labeled=[...rpmForCol].sort((a,b)=>a[0]-b[0]);
    const slopes=[];
    for(let i=1;i<labeled.length;i++){
      const dc=labeled[i][0]-labeled[i-1][0],dv=labeled[i][1]-labeled[i-1][1];
      if(dc>0&&dv>0)slopes.push(dv/dc);
    }
    if(slopes.length){
      slopes.sort((a,b)=>a-b);
      const step=slopes[Math.floor(slopes.length/2)];
      const [anchorCol,anchorRpm]=labeled[Math.floor(labeled.length/2)];
      for(let col=1;col<verticalLines.length-1;col++){
        if(rpmForCol.has(col))continue;
        const inferred=anchorRpm+(col-anchorCol)*step;
        const rpm=SCREENSHOT_RPM_AXIS.find(value=>Math.abs(value-inferred)<=5);
        if(rpm!=null)rpmForCol.set(col,rpm);
      }
    }
  }
  for(let row=1;row<horizontalLines.length-1;row++){
    const item=cellValue(row,0);
    if(item){const tps=SCREENSHOT_TPS_AXIS.find(v=>Math.abs(v-item.value)<=.2);if(tps!=null)tpsForRow.set(row,tps);}
  }
  // TPS spacing is not linear (10, 15, 20 ...), so infer a missing label by
  // its row offset in the known ordered axis instead of doing arithmetic.
  if(tpsForRow.size>=2){
    const offsetCounts=new Map();
    for(const [row,tps] of tpsForRow){
      const axisIndex=SCREENSHOT_TPS_AXIS.indexOf(tps);
      const offset=axisIndex-(row-1);
      offsetCounts.set(offset,(offsetCounts.get(offset)||0)+1);
    }
    const offset=[...offsetCounts].sort((a,b)=>b[1]-a[1])[0]?.[0];
    if(Number.isInteger(offset)){
      for(let row=1;row<horizontalLines.length-1;row++){
        if(tpsForRow.has(row))continue;
        const tps=SCREENSHOT_TPS_AXIS[offset+row-1];
        if(tps!=null)tpsForRow.set(row,tps);
      }
    }
  }
  if(!rpmForCol.size||!tpsForRow.size)throw new Error('無法確認 RPM／TPS 軸；截圖必須同時看得到上方 RPM 與左側 TPS 數字。');
  const detected=[];
  for(const [row,tps] of [...tpsForRow].sort((a,b)=>a[0]-b[0])){
    for(const [col,rpm] of [...rpmForCol].sort((a,b)=>a[0]-b[0])){
      const item=cellValue(row,col);
      if(!item||item.value==null)continue;
      detected.push({tps,rpm,rawValue:item.value,confidence:item.confidence,source});
    }
  }
  const references=detected.map(item=>item.rawValue);
  const cells=[];
  for(const item of detected){
    const repaired=repairRecognizedFuelValue(item.rawValue,references);
    if(repaired.value==null)continue;
    cells.push({
      tps:item.tps,rpm:item.rpm,value:repaired.value,
      confidence:repaired.repaired?Math.min(item.confidence,60):item.confidence,
      source:item.source,repaired:repaired.repaired,ocrValue:item.rawValue
    });
  }
  return cells;
}

async function ensureWorker(progress){
  if(ocrWorker)return ocrWorker;
  if(!globalThis.Tesseract)throw new Error('OCR 元件尚未載入，請重新整理測試頁面。');
  const base=new URL('../vendor/tesseract/',import.meta.url);
  ocrWorker=await globalThis.Tesseract.createWorker('eng',globalThis.Tesseract.OEM.LSTM_ONLY,{
    workerPath:new URL('worker.min.js',base).href,
    workerBlobURL:false,
    langPath:new URL('tessdata/',base).href,
    corePath:base.href,
    logger:message=>progress?.(message),
    errorHandler:error=>console.error('OCR worker error',error)
  });
  await ocrWorker.setParameters({
    tessedit_char_whitelist:'0123456789+-.%',
    tessedit_pageseg_mode:globalThis.Tesseract.PSM.SPARSE_TEXT,
    preserve_interword_spaces:'1'
  });
  return ocrWorker;
}

async function recognizeScreenshot(file,progress){
  const img=await loadImage(file);
  const prepared=prepareImage(img);
  const worker=await ensureWorker(progress);
  const result=await worker.recognize(prepared.canvas,{}, {text:true,tsv:true,blocks:true});
  const tokens=parseTsv(result.data.tsv);
  return tokensToFuelCells(tokens,prepared.geometry.verticalLines,prepared.geometry.horizontalLines,file.name);
}

function renderEditor(onChange){
  const wrap=document.querySelector('#recognizedMapWrap');
  if(!wrap)return;
  let html='<table class="map currentFuelMap"><caption class="srOnly">截圖辨識的目前油量表</caption><thead><tr><th>TPS\\RPM</th>'+
    SCREENSHOT_RPM_AXIS.map(r=>`<th>${r}</th>`).join('')+'</tr></thead><tbody>';
  for(const tps of SCREENSHOT_TPS_AXIS){
    html+=`<tr><th>${tps}%</th>`;
    for(const rpm of SCREENSHOT_RPM_AXIS){
      const key=`${tps}|${rpm}`,item=currentFuelMap.get(key);
      const cls=item?.conflict?'recognitionConflict':item&&item.confidence<65?'recognitionReview':item?'recognitionOk':'';
      const title=item?.repaired?'OCR 已自動補回小數點或首位數，請確認':'';
      html+=`<td class="${cls}"><input inputmode="decimal" aria-label="TPS ${tps}% RPM ${rpm} 目前油量" data-map-key="${key}" value="${item?String(item.value):''}" placeholder="—" title="${title}"></td>`;
    }
    html+='</tr>';
  }
  html+='</tbody></table>';wrap.innerHTML=html;
  wrap.querySelectorAll('[data-map-key]').forEach(input=>input.addEventListener('change',()=>{
    const value=normalizeRecognizedNumber(input.value);
    if(value==null){currentFuelMap.delete(input.dataset.mapKey);input.value='';}
    else{currentFuelMap.set(input.dataset.mapKey,{value,confidence:100,source:'manual',conflict:false});input.value=String(value);}
    document.querySelector('#recognizedCount').textContent=String(currentFuelMap.size);
    onChange?.();
  }));
  document.querySelector('#recognizedCount').textContent=String(currentFuelMap.size);
}

export function initScreenshotMap({onChange}={}){
  const files=document.querySelector('#mapShots'),drop=document.querySelector('#mapShotDrop');
  const button=document.querySelector('#recognizeMap'),clear=document.querySelector('#clearRecognizedMap');
  const list=document.querySelector('#mapShotList'),status=document.querySelector('#mapShotStatus'),panel=document.querySelector('#recognizedMapPanel');
  if(!files||!drop||!button)return;
  let selected=[];
  const setStatus=(text,bad=false)=>{status.textContent=text;status.className=bad?'bad':'';};
  const select=incoming=>{
    try{selected=validateScreenshotFiles(incoming);setStatus('');}
    catch(error){selected=[];setStatus(error.message||String(error),true);}
    list.innerHTML=selected.length?selected.map(file=>`<span class="chip"></span>`).join(''):'尚未選擇截圖';
    [...list.querySelectorAll('.chip')].forEach((chip,index)=>{chip.textContent=selected[index].name;});
    button.disabled=!selected.length;
  };
  files.addEventListener('change',()=>select(files.files));
  drop.addEventListener('click',()=>files.click());
  drop.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();files.click();}});
  ['dragenter','dragover'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.add('drag');}));
  ['dragleave','drop'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.remove('drag');}));
  drop.addEventListener('drop',event=>select(event.dataTransfer.files));
  button.addEventListener('click',async()=>{
    button.disabled=true;let completed=0,failed=0,totalConflicts=0;
    try{
      for(let i=0;i<selected.length;i++){
        setStatus(`正在辨識 ${i+1}/${selected.length}：${selected[i].name}（第一次會載入約 7 MB 本機 OCR）`);
        try{
          const cells=await recognizeScreenshot(selected[i],message=>{
            if(message.status==='recognizing text')setStatus(`正在辨識 ${i+1}/${selected.length}：${Math.round((message.progress||0)*100)}%`);
          });
          const merged=mergeRecognizedCells(cells);totalConflicts+=merged.conflicts;completed++;
        }catch(error){
          console.warn('screenshot OCR failed',error);
          failed++;
          const reason=error?.message||String(error??'OCR 元件未回傳錯誤說明');
          setStatus(`${selected[i].name}：${reason}`,true);
        }
      }
      renderEditor(onChange);panel.hidden=false;
      setStatus(`辨識完成：${completed} 張成功、${failed} 張需重拍，取得 ${currentFuelMap.size} 格${totalConflicts?`，${totalConflicts} 格衝突待確認`:''}。` ,failed>0);
      onChange?.();
    }finally{button.disabled=!selected.length;}
  });
  clear.addEventListener('click',()=>{currentFuelMap.clear();renderEditor(onChange);panel.hidden=true;setStatus('已清除截圖辨識結果。');onChange?.();});
}
