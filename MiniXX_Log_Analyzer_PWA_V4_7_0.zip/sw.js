const CACHE='minixx-log-v4.7.0-r2';
const VERSION='v=4.7.0';
const ASSETS=[
  './',
  `./index.html?${VERSION}`,
  `./compare.html?${VERSION}`,
  `./temperature.html?${VERSION}`,
  `./compression.html?${VERSION}`,
  `./guide.html?${VERSION}`,
  `./tuning.html?${VERSION}`,
  `./faq.html?${VERSION}`,
  `./privacy.html?${VERSION}`,
  `./articles.html?${VERSION}`,
  `./about.html?${VERSION}`,
  `./articles/methodology.html?${VERSION}`,
  `./articles/log-quality.html?${VERSION}`,
  `./articles/afr-basics.html?${VERSION}`,
  `./articles/fuel-cl.html?${VERSION}`,
  `./articles/fuel-step-case.html?${VERSION}`,
  `./articles/compare-logs.html?${VERSION}`,
  `./articles/ignition-map.html?${VERSION}`,
  `./articles/screenshot-map.html?${VERSION}`,
  `./articles/troubleshooting.html?${VERSION}`,
  './robots.txt',
  './sitemap.xml',
  `./styles.css?${VERSION}`,
  `./views.css?${VERSION}`,
  `./manifest.webmanifest?${VERSION}`,
  `./src/app.js?${VERSION}`,
  `./src/compare.js?${VERSION}`,
  `./src/temperature.js?${VERSION}`,
  `./src/compression.js?${VERSION}`,
  `./src/compression-core.js?${VERSION}`,
  `./src/faq.js?${VERSION}`,
  `./src/analyzer.js?${VERSION}`,
  `./src/zip.js?${VERSION}`,
  `./src/screenshot-map.js?${VERSION}`,
  `./src/i18n.js?${VERSION}`,
  `./src/locales/en.generated.js?${VERSION}`,
  `./src/locales/en-overrides.js?${VERSION}`,
  `./vendor/tesseract/tesseract.min.js?${VERSION}`,
  './vendor/tesseract/worker.min.js',
  './assets/icon-log.svg',
  './assets/icon-log-192.svg',
  './assets/cases/analysis-flow.svg',
  './assets/cases/product-overview.jpg'
];

self.addEventListener('install',event=>{
  const requests=ASSETS.map(path=>new Request(new URL(path,self.location.href),{cache:'reload'}));
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(requests)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(key=>key.startsWith('minixx-log-')&&key!==CACHE).map(key=>caches.delete(key))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin)return;

  if(event.request.mode==='navigate'||event.request.destination==='document'||url.pathname.endsWith('.html')||url.pathname.endsWith('/')){
    event.respondWith(
      fetch(event.request,{cache:'no-cache'})
        .then(async response=>{
          if(response.ok){
            const cache=await caches.open(CACHE);
            await cache.put(event.request,response.clone());
          }
          return response;
        })
        .catch(async()=>{
          const cache=await caches.open(CACHE);
          const canonical=new URL(url.href);
          if(canonical.pathname.endsWith('/'))canonical.pathname+='index.html';
          canonical.search=VERSION;
          return await cache.match(canonical.href)||await cache.match(event.request)||await cache.match(canonical.href,{ignoreSearch:true})||
            new Response('Page not cached yet. Please reconnect and try again. / 此頁尚未下載，請連線後再開啟。',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
        })
    );
    return;
  }

  event.respondWith(
    caches.open(CACHE).then(async cache=>await cache.match(event.request)||fetch(event.request).then(async response=>{
      if(response.ok){
        await cache.put(event.request,response.clone());
      }
      return response;
    }))
  );
});
