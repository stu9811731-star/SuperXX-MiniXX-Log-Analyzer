import {parseLogText, analyzeTemperatureCompensation, temperatureCompensationToCsv} from './analyzer.js?v=4.7.0';
import {unzipLoga} from './zip.js?v=4.7.0';

const $ = selector => document.querySelector(selector);
const filesEl=$('#files'), drop=$('#drop'), runBtn=$('#run'), result=$('#result'), statusEl=$('#status');
const MAX_FILES=20, MAX_FILE_BYTES=25*1024*1024;
const MAX_TOTAL_FILE_BYTES=100*1024*1024, MAX_TOTAL_ROWS=500000;
let selected=[], latestReport=null, busy=false;

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(v,n=2){return v==null?'—':Number(v).toFixed(n);}
function signed(v,n=1){if(v==null)return'—';const x=Number(v);return `${x>0?'+':''}${x.toFixed(n)}%`;}
function badge(v){return `<span class="badge ${String(v).toLowerCase().replaceAll(' ','-')}">${esc(v)}</span>`;}
function setStatus(text,bad=false){statusEl.textContent=text;statusEl.className=bad?'bad':'';}
function invalidate(){
  latestReport=null;
  result.hidden=true;
  $('#exportTemperature').disabled=true;
}

function updateFiles(){
  $('#fileList').innerHTML=selected.length?selected.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇檔案';
  runBtn.disabled=!selected.length;
}
function selectFiles(files) {
  if(busy)return;
  invalidate();
  const next = [...files];
  if (next.length > MAX_FILES) { selected=[]; updateFiles(); setStatus(`一次最多可匯入 ${MAX_FILES} 個 Log`,true); return; }
  for (const file of next) {
    if (!/\.(?:loga|log|txt|csv|zip)$/i.test(file.name)) { selected=[]; updateFiles(); setStatus('支援 .loga / .log / .txt / .csv / .zip',true); return; }
    if (file.size > MAX_FILE_BYTES) { selected=[]; updateFiles(); setStatus(`${file.name} 超過 25 MB 上限`,true); return; }
  }
  if (next.reduce((total,file)=>total+file.size,0) > MAX_TOTAL_FILE_BYTES) {
    selected=[]; updateFiles(); setStatus('Log 總容量超過 100 MB 上限',true); return;
  }
  selected=next; updateFiles(); setStatus('');
}
filesEl.addEventListener('change',()=>selectFiles(filesEl.files));
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add('drag');}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove('drag');}));
drop.addEventListener('drop',e=>selectFiles(e.dataTransfer.files));
drop.addEventListener('click',()=>filesEl.click());
drop.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();filesEl.click();}});

function getSettings(){
  return {
    ecuModel:'MiniXX',
    logPlatform:'auto',
    fuelClMode:$('#fuelClMode').value,
    temperatureReferenceBandId:$('#referenceBand').value
  };
}

function updateReferenceHint(){
  const label=$('#referenceBand').selectedOptions[0].textContent.replace('（預設）','');
  const base=Number($('#referenceBand').value);
  $('#referenceHint').textContent=`以 ${label} 格（${base}～未滿${base+16}°C）為基準；其他分析條件自動使用預設值。`;
}

async function loadSelected(){
  const logs=[]; let totalRows=0;
  const addLog=(name,text)=>{
    const rows=parseLogText(text,name);
    totalRows+=rows.length;
    if(totalRows>MAX_TOTAL_ROWS)throw new Error('Log 解析後總資料超過 500,000 列上限；請分批分析。');
    logs.push({name,rows,platform:rows.meta?.platform??'unknown'});
  };
  for (const f of selected) {
    if (/\.zip$/i.test(f.name)) {
      const entries=await unzipLoga(await f.arrayBuffer());
      for (const e of entries) addLog(`${f.name}/${e.name}`,e.text);
    } else addLog(f.name,await f.text());
  }
  return logs;
}

function renderTemperatureCompensation(report){
  const s=report.summary;
  $('#temperatureDescription').textContent=`以 ${report.referenceBand} 的相同 TPS／RPM 格位為基準，比較其他溫度區間的燃油偏差。正值代表加油，負值代表減油。`;
  $('#temperatureSummary').innerHTML=
    `<div><b>${s.referenceCells}</b><span>基準格位</span></div>`+
    `<div><b>${s.actionableBands}</b><span>可調整區間</span></div>`+
    `<div><b>${s.acceptedSamples}</b><span>有效樣本</span></div>`+
    `<div><b>${s.inputRows}</b><span>原始資料</span></div>`;
  const actionLabel=band=>{
    if(band.reference)return '基準 0.0%';
    if(band.confidence==='Low'||band.status==='Verify'||band.status==='Insufficient')return '—';
    if(!band.suggestedPct)return '維持 0.0%';
    return `${band.suggestedPct>0?'加油':'減油'} ${signed(band.suggestedPct,1)}`;
  };
  $('#temperatureBody').innerHTML=report.bands.map(band=>`<tr class="temp-${band.confidence.toLowerCase()} temp-${band.status.toLowerCase()}">`+
    `<td><b>${esc(band.label)}</b></td><td>${band.samples}</td><td>${fmt(band.effectiveN,1)}</td><td>${fmt(band.seconds,1)}</td>`+
    `<td>${band.matchedCells}</td><td>${band.differencePct==null?'—':signed(band.differencePct,1)}</td><td>${band.madPct==null?'—':`${fmt(band.madPct,1)}%`}</td>`+
    `<td><b>${actionLabel(band)}</b></td><td>${badge(band.confidence)}</td><td>${badge(band.status)}</td></tr>`).join('');
  const labels={temperatureRange:'T_Eng 低於 0°C 或達 144°C',afr:'AFR 缺失或超出範圍',wbo2NotReady:'WBO2 未就緒',fuelCut:'斷油／FuelPW≈0',afterAcceleration:'加速補油後排除',fuelCl:'Fuel_CL 無法換算',outOfAxis:'超出 TPS／RPM 軸',entryWait:'進格等待',shortSegment:'穩態時間不足'};
  $('#temperatureExclusions').innerHTML=Object.entries(report.exclusions).map(([key,value])=>`<div><span>${esc(labels[key]||key)}</span><b>${value}</b></div>`).join('');
  $('#temperatureNote').textContent=`比較基準：${report.referenceBand}。0～未滿16°C 歸入 0°C 格、16～未滿32°C 歸入 16°C 格，依此類推；128°C 格涵蓋 128～未滿144°C。建議只拉回 ±${report.settings.correctionDeadbandPct}% 安全帶，依 0.8% 步進且單次不超過 ±${report.settings.maxSuggestionPct}%；請先備份原設定並以新 Log 驗證。`;
  $('#exportTemperature').disabled=!report.bands.some(band=>band.matchedCells>0);
}

const settingsInputs=[...document.querySelectorAll('.temperatureSettings select')];
settingsInputs.forEach(input=>input.addEventListener('change',()=>{
  const hadReport=latestReport!==null;
  invalidate();
  updateReferenceHint();
  if(hadReport)setStatus('分析設定已變更，請重新執行溫度補償分析。');
}));

runBtn.addEventListener('click',async()=>{
  if(busy||!selected.length)return;
  busy=true;
  runBtn.disabled=true;
  filesEl.disabled=true;
  drop.setAttribute('aria-disabled','true');
  invalidate();
  setStatus('正在比對各溫度區間的相同 TPS／RPM 格位…');
  try{
    const settings=getSettings();
    settingsInputs.forEach(input=>{input.disabled=true;});
    const logs=await loadSelected();
    latestReport=analyzeTemperatureCompensation(logs,settings);
    renderTemperatureCompensation(latestReport);
    result.hidden=false;
    const summary=latestReport.summary;
    setStatus(`完成：${logs.length} 個 Log，${summary.referenceCells} 個基準格位，${summary.actionableBands} 個區間可調整。${summary.referenceCells===0?`尚無足夠的 ${latestReport.referenceBand} 基準資料，請補充 Log。`:''}`);
  }catch(error){
    invalidate();
    setStatus(error.message||String(error),true);
  }finally{
    busy=false;
    filesEl.disabled=false;
    drop.removeAttribute('aria-disabled');
    settingsInputs.forEach(input=>{input.disabled=false;});
    runBtn.disabled=!selected.length;
  }
});

$('#exportTemperature').addEventListener('click',()=>{
  if(!latestReport)return;
  const blob=new Blob(['\uFEFF'+temperatureCompensationToCsv(latestReport)],{type:'text/csv;charset=utf-8'});
  const link=document.createElement('a');
  link.href=URL.createObjectURL(blob);
  link.download='minixx_t_eng_compensation_v4_6_1.csv';
  link.click();
  setTimeout(()=>URL.revokeObjectURL(link.href),1000);
});
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js?v=4.7.0').catch(console.warn);
