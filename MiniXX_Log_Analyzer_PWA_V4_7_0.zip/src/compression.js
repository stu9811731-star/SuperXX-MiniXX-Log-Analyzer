import {calculateCompressionRatio} from './compression-core.js?v=4.7.0';

const form = document.querySelector('#compressionForm');
const ratioValue = document.querySelector('#ratioValue');
const resultStatus = document.querySelector('#compressionStatus');
const output = {
  total: document.querySelector('#totalDisplacement'),
  swept: document.querySelector('#sweptVolume'),
  clearance: document.querySelector('#clearanceVolume'),
  chamber: document.querySelector('#chamberResult'),
  piston: document.querySelector('#pistonResult'),
  gasket: document.querySelector('#gasketResult'),
  deck: document.querySelector('#deckResult')
};

const value = id => document.querySelector(`#${id}`).value;
const cc = value => `${value.toFixed(2)} cc`;

function render() {
  try {
    const result = calculateCompressionRatio({
      boreMm: value('boreMm'),
      strokeMm: value('strokeMm'),
      chamberCc: value('chamberCc'),
      pistonCc: value('pistonCc'),
      gasketBoreMm: value('gasketBoreMm'),
      gasketThicknessMm: value('gasketThicknessMm'),
      deckMm: value('deckMm'),
      cylinders: value('cylinders')
    });

    ratioValue.textContent = `${result.ratio.toFixed(2)} : 1`;
    output.total.textContent = cc(result.totalDisplacementCc);
    output.swept.textContent = cc(result.sweptCc);
    output.clearance.textContent = cc(result.clearanceCc);
    output.chamber.textContent = cc(result.chamberCc);
    output.piston.textContent = cc(result.pistonCc);
    output.gasket.textContent = cc(result.gasketCc);
    output.deck.textContent = cc(result.deckCc);
    resultStatus.textContent = '已依目前輸入更新。';
    resultStatus.classList.remove('bad');
  } catch (error) {
    ratioValue.textContent = '—';
    Object.values(output).forEach(node => { node.textContent = '—'; });
    resultStatus.textContent = error.message;
    resultStatus.classList.add('bad');
  }
}

form.addEventListener('submit', event => {
  event.preventDefault();
  render();
});
form.addEventListener('input', render);
form.addEventListener('reset', () => setTimeout(render));
render();
