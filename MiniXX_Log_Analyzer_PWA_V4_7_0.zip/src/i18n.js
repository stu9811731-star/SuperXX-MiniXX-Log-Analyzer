import {EN_EXACT} from './locales/en.generated.js?v=4.7.0';
import {EN_OVERRIDES, polishEnglish} from './locales/en-overrides.js?v=4.7.0';

const STORAGE_KEY = 'xxfuel-language';
const CJK = /[\u3400-\u9fff]/;
const CJK_PUNCTUATION = /[，。；：（）、～]/;
const ORIGINAL_TEXT = Symbol('xxfuelOriginalText');
const originalAttributes = new WeakMap();
const attributeNames = ['aria-label', 'alt', 'content', 'placeholder', 'title'];
let currentLanguage = 'zh-Hant';
let applying = false;

const dictionary = {...EN_EXACT, ...EN_OVERRIDES};
const substringEntries = Object.entries(dictionary)
  .filter(([source, translated]) => source.length >= 2 && CJK.test(source) && translated)
  .sort((a, b) => b[0].length - a[0].length);

const dynamicRules = [
  [/^一次最多可匯入 (\d+) 個 Log$/, 'You can import up to $1 logs at a time.'],
  [/^每組最多 (\d+) 個 Log$/, 'Each group supports up to $1 logs.'],
  [/^(.+) 超過 (\d+) MB 上限。?$/, '$1 exceeds the $2 MB limit.'],
  [/^Log 總容量超過 (\d+) MB 上限$/, 'Total log size exceeds the $1 MB limit.'],
  [/^每組 Log 總容量超過 (\d+) MB 上限$/, 'Total log size for each group exceeds the $1 MB limit.'],
  [/^Log 解析後總資料超過 ([\d,]+) 列上限；請分批分析。$/, 'Parsed log data exceeds the $1-row limit. Analyze it in smaller batches.'],
  [/^每組 Log 解析後總資料超過 ([\d,]+) 列上限；請分批比較。$/, 'Parsed data in one group exceeds the $1-row limit. Compare it in smaller batches.'],
  [/^支援 (.+)$/, 'Supported formats: $1'],
  [/^正在辨識 Log 系統並執行 (.+) 分析…$/, 'Detecting the log format and running $1 analysis…'],
  [/^正在分析兩組 Log…$/, 'Analyzing both log groups…'],
  [/^完成：(.+) 個調整前 Log、(.+) 個調整後 Log$/, 'Complete: $1 before logs and $2 after logs.'],
  [/^完成：(.+) · MiniXX · (\d+) 個 Log，(\d+) 個有效格位，(\d+) 格建議修正$/, 'Complete: $1 · MiniXX · $2 logs, $3 accepted cells, $4 suggested cells.'],
  [/^Fuel_CL 計算方式已變更，請重新執行分析。$/, 'The Fuel_CL setting changed. Run the analysis again.'],
  [/^Log 系統設定已變更，請重新執行分析。$/, 'The log platform setting changed. Run the analysis again.'],
  [/^分析設定已變更，請重新執行溫度補償分析。$/, 'The analysis settings changed. Run temperature compensation again.'],
  [/^正在比對各溫度區間的相同 TPS／RPM 格位…$/, 'Comparing matching TPS/RPM cells across temperature ranges…'],
  [/^以 (.+) 格（(.+)～未滿(.+)°C）為基準；其他分析條件自動使用預設值。$/, 'Using the $1 bin ($2 to below $3°C) as the reference; all other analysis settings use their defaults.'],
  [/^辨識完成：(\d+) 張成功、(\d+) 張需重拍，取得 (\d+) 格(.*)。$/, 'Recognition complete: $1 succeeded, $2 need new screenshots, and $3 cells were captured$4.'],
  [/^正在辨識 (\d+)\/(\d+)：(.+)（第一次會載入約 7 MB 本機 OCR）$/, 'Recognizing $1/$2: $3 (the first run loads about 7 MB of local OCR data)'],
  [/^正在辨識 (\d+)\/(\d+)：(\d+)%$/, 'Recognizing $1/$2: $3%'],
  [/^已清除截圖辨識結果。$/, 'Screenshot recognition results cleared.'],
  [/^此格沒有可執行的燃油修改建議；狀態 (.+)；可信度 (.+)；N=(.+)$/, 'No actionable fuel suggestion for this cell; status $1; confidence $2; N=$3'],
  [/^目標 (.+) · N=(.+)$/, 'Target $1 · N=$2'],
  [/^實際 (.+) · N=(.+)$/, 'Actual $1 · N=$2'],
  [/^空燃比差異 (.+)$/, 'AFR difference $1'],
  [/^全域 (.+)→(.+) · 最終供油 (.+)→(.+)$/, 'Global $1→$2 · Final fuel $3→$4'],
  [/^(.+)% \/ (.+) rpm — (.+)（燃油修正 (.+)）$/, '$1% / $2 rpm — $3 (fuel correction $4)'],
  [/^(.+)必須介於 (.+)$/, '$1 must be within $2'],
  [/^(.+): 找不到足夠的資料列$/, '$1: not enough data rows were found.'],
  [/^(.+): 找不到 RPM\/TPS 欄位標題$/, '$1: RPM/TPS headers were not found.'],
  [/^(.+): 缺少必要欄位 (.+)$/, '$1: required fields are missing: $2'],
  [/^(.+): 沒有可解析的資料$/, '$1: no parsable data was found.'],
];

function normalize(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function translateWithRules(value) {
  for (const [pattern, replacement] of dynamicRules) {
    if (pattern.test(value)) return value.replace(pattern, replacement);
  }
  return null;
}

export function translateText(value) {
  const source = normalize(value);
  if (!source || (!CJK.test(source) && !CJK_PUNCTUATION.test(source))) return value;
  const exact = dictionary[source];
  if (exact) return polishEnglish(exact);
  const ruled = translateWithRules(source);
  if (ruled) return polishEnglish(ruled);

  let translated = source;
  for (const [zh, en] of substringEntries) {
    if (translated.includes(zh)) translated = translated.split(zh).join(en);
  }
  translated = translated
    .replaceAll('，', ', ')
    .replaceAll('。', '.')
    .replaceAll('；', '; ')
    .replaceAll('：', ': ')
    .replaceAll('（', ' (')
    .replaceAll('）', ')')
    .replaceAll('、', ', ')
    .replaceAll('／', ' / ')
    .replaceAll('～', '–');
  return polishEnglish(translated);
}

function withWhitespace(original, translated) {
  const leading = original.match(/^\s*/)?.[0] ?? '';
  const trailing = original.match(/\s*$/)?.[0] ?? '';
  return `${leading}${translated}${trailing}`;
}

function ignored(node) {
  return node.parentElement?.closest('[data-i18n-ignore],script,style,noscript') != null;
}

function applyTextNode(node) {
  if (ignored(node)) return;
  if (currentLanguage === 'zh-Hant') {
    if (node[ORIGINAL_TEXT] != null && node.nodeValue !== node[ORIGINAL_TEXT]) node.nodeValue = node[ORIGINAL_TEXT];
    return;
  }
  const current = node.nodeValue ?? '';
  const previous = node[ORIGINAL_TEXT];
  if (previous != null) {
    const expected = withWhitespace(previous, translateText(previous));
    if (current === expected) return;
  }
  if (!CJK.test(current) && !CJK_PUNCTUATION.test(current)) return;
  node[ORIGINAL_TEXT] = current;
  node.nodeValue = withWhitespace(current, translateText(current));
}

function applyAttributes(element) {
  if (element.closest('[data-i18n-ignore],script,style,noscript')) return;
  let originals = originalAttributes.get(element);
  if (!originals) {
    originals = new Map();
    originalAttributes.set(element, originals);
  }
  for (const name of attributeNames) {
    if (!element.hasAttribute(name)) continue;
    if (currentLanguage === 'zh-Hant') {
      if (originals.has(name)) element.setAttribute(name, originals.get(name));
      continue;
    }
    const current = element.getAttribute(name) ?? '';
    const previous = originals.get(name);
    if (previous != null && current === translateText(previous)) continue;
    if (!CJK.test(current)) continue;
    originals.set(name, current);
    element.setAttribute(name, translateText(current));
  }
}

function applyTree(root = document.body) {
  applying = true;
  try {
    if (root.nodeType === Node.TEXT_NODE) applyTextNode(root);
    if (root.nodeType === Node.ELEMENT_NODE) applyAttributes(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let node = walker.currentNode;
    while (node) {
      if (node.nodeType === Node.TEXT_NODE) applyTextNode(node);
      else if (node.nodeType === Node.ELEMENT_NODE) applyAttributes(node);
      node = walker.nextNode();
    }
    for (const meta of document.querySelectorAll('meta[content]')) applyAttributes(meta);
    const titleText = document.querySelector('title')?.firstChild;
    if (titleText) applyTextNode(titleText);
  } finally {
    applying = false;
  }
}

function updateToggle() {
  const button = document.querySelector('[data-language-toggle]');
  if (!button) return;
  const english = currentLanguage === 'en';
  button.textContent = english ? '繁中' : 'EN';
  button.setAttribute('aria-label', english ? '切換為繁體中文' : 'Switch to English');
  button.setAttribute('title', english ? '切換為繁體中文' : 'Switch to English');
}

export function setLanguage(language, {persist = true} = {}) {
  currentLanguage = language === 'en' ? 'en' : 'zh-Hant';
  document.documentElement.lang = currentLanguage;
  document.body.dataset.language = currentLanguage;
  if (persist) {
    try { localStorage.setItem(STORAGE_KEY, currentLanguage); } catch {}
  }
  applyTree(document.body);
  updateToggle();
  document.dispatchEvent(new CustomEvent('xxfuel:languagechange', {detail: {language: currentLanguage}}));
}

export function getLanguage() {
  return currentLanguage;
}

function preferredLanguage() {
  const requested = new URLSearchParams(location.search).get('lang');
  if (requested === 'en' || requested === 'zh-Hant' || requested === 'zh') return requested === 'en' ? 'en' : 'zh-Hant';
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'en' || saved === 'zh-Hant') return saved;
  } catch {}
  return 'zh-Hant';
}

function installToggle() {
  const header = document.querySelector('body > header');
  if (!header || header.querySelector('[data-language-toggle]')) return;
  let actions = header.querySelector('.headerActions');
  if (!actions) {
    actions = document.createElement('div');
    actions.className = 'headerActions';
    actions.dataset.i18nIgnore = '';
    const install = header.querySelector('#install');
    if (install) actions.append(install);
    header.append(actions);
  }
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'languageToggle';
  button.dataset.languageToggle = '';
  button.dataset.i18nIgnore = '';
  button.addEventListener('click', () => setLanguage(currentLanguage === 'en' ? 'zh-Hant' : 'en'));
  actions.append(button);
}

installToggle();
setLanguage(preferredLanguage(), {persist: false});

const observer = new MutationObserver(records => {
  if (applying || currentLanguage !== 'en') return;
  for (const record of records) {
    if (record.type === 'characterData') applyTree(record.target);
    else for (const node of record.addedNodes) applyTree(node);
  }
});
observer.observe(document.body, {subtree: true, childList: true, characterData: true});

globalThis.XXFueLI18n = {getLanguage, setLanguage, translateText};
