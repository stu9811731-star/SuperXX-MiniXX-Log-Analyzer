import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {EN_EXACT} from '../src/locales/en.generated.js';
import {EN_OVERRIDES,polishEnglish} from '../src/locales/en-overrides.js';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const pages=[
  ...readdirSync(root,{withFileTypes:true}).filter(entry=>entry.isFile()&&entry.name.endsWith('.html')).map(entry=>entry.name),
  ...readdirSync(resolve(root,'articles'),{withFileTypes:true}).filter(entry=>entry.isFile()&&entry.name.endsWith('.html')).map(entry=>`articles/${entry.name}`)
];
const CJK=/[\u3400-\u9fff]/;
const dictionary={...EN_EXACT,...EN_OVERRIDES};
const normalize=value=>value.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/\s+/g,' ').trim();

function visibleStrings(html){
  const values=[];
  const withoutCode=html.replace(/<(script|style)\b[\s\S]*?<\/\1>/gi,'');
  for(const match of withoutCode.matchAll(/>([^<>]+)</g)){
    const value=normalize(match[1]);
    if(value&&CJK.test(value))values.push(value);
  }
  for(const match of withoutCode.matchAll(/\b(?:content|alt|aria-label|title|placeholder)="([^"]+)"/gi)){
    const value=normalize(match[1]);
    if(value&&CJK.test(value))values.push(value);
  }
  return values;
}

test('every public page loads the local bilingual switch at the current version',()=>{
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const prefix=page.startsWith('articles/')?'..':'.';
    assert.equal((html.match(/src="\.\.??\/src\/i18n\.js\?v=4\.7\.0"/g)||[]).length,1,`${page} must load one language switch`);
    assert.match(html,new RegExp(`src="${prefix.replace('.','\\.')}\\/src\\/i18n\\.js\\?v=4\\.7\\.0"`));
  }
});

test('all current static Chinese page strings have a bundled English translation',()=>{
  const missing=[];
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    for(const value of visibleStrings(html))if(!dictionary[value])missing.push(`${page}: ${value}`);
  }
  assert.deepEqual(missing,[]);
});

test('bundled English output does not retain Chinese text',()=>{
  const bad=[];
  for(const [source,english] of Object.entries(dictionary)){
    const polished=polishEnglish(english);
    if(CJK.test(polished))bad.push(`${source} => ${polished}`);
  }
  assert.deepEqual(bad,[]);
});

test('language switch is local, persistent, and observes dynamically rendered results',()=>{
  const source=readFileSync(resolve(root,'src/i18n.js'),'utf8');
  assert.match(source,/xxfuel-language/);
  assert.match(source,/localStorage\.setItem/);
  assert.match(source,/MutationObserver/);
  assert.match(source,/data-language-toggle|dataset\.languageToggle/);
  assert.match(source,/document\.documentElement\.lang/);
  assert.match(source,/querySelector\('title'\)/);
  assert.doesNotMatch(source,/fetch\(|translate\.google|googleapis|deepl/i);
});
