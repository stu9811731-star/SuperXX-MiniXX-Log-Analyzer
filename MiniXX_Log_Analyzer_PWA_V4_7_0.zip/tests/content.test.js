import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readdirSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const version=readFileSync(resolve(root,'sw.js'),'utf8').match(/const VERSION=['"]([^'"]+)/)[1];
const pages=[
  'index.html','compare.html','temperature.html','compression.html','guide.html','tuning.html','faq.html','privacy.html',
  'articles.html','about.html','articles/log-quality.html','articles/afr-basics.html',
  'articles/fuel-cl.html','articles/methodology.html','articles/fuel-step-case.html','articles/compare-logs.html',
  'articles/ignition-map.html','articles/screenshot-map.html','articles/troubleshooting.html'
];
const beaconUrl='https://static.cloudflareinsights.com/beacon.min.js';
const analyticsEndpoint='https://cloudflareinsights.com';
const analyticsToken='8214350e854848dcbedc69c54282669b';

test('public page inventory matches the HTML files and sitemap',()=>{
  const discovered=[
    ...readdirSync(root,{withFileTypes:true}).filter(entry=>entry.isFile()&&entry.name.endsWith('.html')).map(entry=>entry.name),
    ...readdirSync(resolve(root,'articles'),{withFileTypes:true}).filter(entry=>entry.isFile()&&entry.name.endsWith('.html')).map(entry=>`articles/${entry.name}`)
  ].sort();
  assert.deepEqual(discovered,[...pages].sort());

  const sitemap=readFileSync(resolve(root,'sitemap.xml'),'utf8');
  for(const page of pages){
    const url=page==='index.html'?'https://xxfuel.com/':`https://xxfuel.com/${page}`;
    assert.match(sitemap,new RegExp(`<loc>${url.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}<\\/loc>`),`${page} is missing from sitemap.xml`);
  }
  assert.equal((sitemap.match(/<loc>/g)||[]).length,pages.length,'sitemap.xml contains an unexpected number of public pages');
});

test('all content pages have unique titles and working local page links',()=>{
  const titles=new Set();
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const title=html.match(/<title>([^<]+)<\/title>/)?.[1];
    assert.ok(title,`${page} is missing a title`);
    assert.ok(!titles.has(title),`${page} duplicates title ${title}`);
    titles.add(title);

    for(const [,href] of html.matchAll(/href="([^"]+)"/g)){
      if(!href.startsWith('.')||href.startsWith('..')&&href.includes('://'))continue;
      const withoutQuery=href.split(/[?#]/)[0];
      if(!withoutQuery||!withoutQuery.endsWith('.html'))continue;
      assert.ok(existsSync(resolve(root,dirname(page),withoutQuery)),`${page} links to missing ${href}`);
      assert.equal(new URL(href,'https://xxfuel.com/').search,`?${version}`,`${page} mixes a stale page version in ${href}`);
    }
  }
});

test('article pages do not include ad units inside instructional content',()=>{
  for(const page of pages.filter(page=>page==='articles.html'||page.startsWith('articles/'))){
    const html=readFileSync(resolve(root,page),'utf8');
    assert.doesNotMatch(html,/adsbygoogle|pagead2\.googlesyndication\.com/);
  }
});

test('method and strengthened case pages expose reproducible evidence and limitations',()=>{
  const methodology=readFileSync(resolve(root,'articles/methodology.html'),'utf8');
  for(const term of ['程式預設','計算公式','保守規則','effectiveN','weighted MAD','±3%','11%','0.8','已知限制']){
    assert.match(methodology,new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')),`methodology is missing ${term}`);
  }
  assert.match(methodology,/作者：XXFueL 製作者/);
  assert.match(methodology,/首次發布：2026-09-16/);
  assert.match(methodology,/方法版本：V4\.4\.2/);

  for(const page of ['articles/fuel-step-case.html','articles/compare-logs.html','articles/screenshot-map.html']){
    const html=readFileSync(resolve(root,page),'utf8');
    assert.match(html,/class="evidenceTable"/,`${page} needs a visible HTML evidence table`);
    assert.match(html,/作者：XXFueL 製作者/,`${page} needs a stable author byline`);
    assert.match(html,/2026-09-16/,`${page} needs an honest modified date`);
    assert.match(html,new RegExp(`methodology\\.html\\?${version.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}`),`${page} must link to the public method`);
  }
});

test('published explanatory images are local, dimensioned and accessible',()=>{
  for(const page of ['index.html','articles/methodology.html']){
    const html=readFileSync(resolve(root,page),'utf8');
    for(const image of html.matchAll(/<img\b[^>]*src="([^"]+)"[^>]*>/g)){
      const tag=image[0],src=image[1].split(/[?#]/)[0];
      assert.match(tag,/\balt="[^"]+"/,`${page} has an image without useful alt text`);
      assert.match(tag,/\bwidth="\d+"/,`${page} has an image without width`);
      assert.match(tag,/\bheight="\d+"/,`${page} has an image without height`);
      assert.ok(existsSync(resolve(root,dirname(page),src)),`${page} links to missing image ${src}`);
    }
  }
});

test('every public page enables the same privacy-limited Cloudflare analytics beacon',()=>{
  const tokens=new Set();
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    assert.equal((html.match(/static\.cloudflareinsights\.com\/beacon\.min\.js/g)||[]).length,2,`${page} must allow and load exactly one beacon`);

    const script=html.match(/<script\b[^>]*src="https:\/\/static\.cloudflareinsights\.com\/beacon\.min\.js"[^>]*><\/script>/)?.[0];
    assert.ok(script,`${page} is missing the analytics script`);
    assert.match(script,/type="module"/,`${page} must use Cloudflare's module snippet`);
    const beaconJson=script.match(/data-cf-beacon='([^']+)'/)?.[1];
    assert.ok(beaconJson,`${page} is missing the analytics site token`);
    const token=JSON.parse(beaconJson).token;
    assert.match(token,/^[0-9a-f]{32}$/,`${page} has an invalid analytics site token`);
    assert.equal(token,analyticsToken,`${page} uses the report site tag instead of the installation token`);
    tokens.add(token);

    const csp=html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)?.[1];
    assert.ok(csp,`${page} is missing its content security policy`);
    assert.match(csp,new RegExp(`script-src[^;]*${beaconUrl.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}`),`${page} does not allow the exact analytics script`);
    assert.match(csp,new RegExp(`connect-src[^;]*${analyticsEndpoint.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}`),`${page} does not allow the analytics endpoint`);
    assert.doesNotMatch(csp,/(?:^|[ ;])\*(?:[ ;]|$)/,`${page} uses a wildcard CSP source`);
    assert.doesNotMatch(csp,/'unsafe-inline'/,`${page} weakens CSP with unsafe-inline`);
    assert.match(html,/href="\.{1,2}\/privacy\.html\?v=[^"]+"/,`${page} must link to the privacy disclosure`);
  }
  assert.equal(tokens.size,1,'public pages must use one shared analytics site token');
});

test('privacy page discloses analytics while excluding vehicle analysis data',()=>{
  const html=readFileSync(resolve(root,'privacy.html'),'utf8');
  assert.match(html,/Cloudflare Web Analytics/);
  for(const excluded of ['Log','ZIP','油量表截圖','OCR','ECU 數值','分析結果'])assert.match(html,new RegExp(excluded));
  assert.match(html,/無法回補先前的瀏覽人數/);
  assert.match(html,/xxfuel-language/);
  assert.match(html,/不會送到翻譯服務/);
});

test('every public page uses the same XXFueL header brand',()=>{
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const headerBrand=html.match(/<header[^>]*>[\s\S]*?<p class="eyebrow brandEyebrow">([^<]+)<\/p>/)?.[1];
    assert.equal(headerBrand,'XXFueL',`${page} has an inconsistent header brand`);
    assert.match(html,/<title>[^<]*(?:｜XXFueL|XXFueL｜)[^<]*<\/title>/,`${page} title does not use XXFueL consistently`);
  }
});

test('every public page links to the compression calculator',()=>{
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    assert.match(html,/href="\.{1,2}\/compression\.html\?v=[^"]+"/,`${page} is missing the compression calculator navigation link`);
  }
});

test('navigation exposes three tools and folds the other pages into one menu',()=>{
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const nav=html.match(/<nav class="siteNav compactNav" aria-label="網站導覽">([\s\S]*?)<\/nav>/)?.[1];
    assert.ok(nav,`${page} is missing the compact navigation`);

    const primary=nav.split('<details class="navMore">')[0];
    assert.equal((primary.match(/<a\b/g)||[]).length,3,`${page} must keep exactly three primary navigation links`);
    assert.match(primary,/>分析工具<\/a>/,`${page} is missing the primary analysis link`);
    assert.match(primary,/>前後比較<\/a>/,`${page} is missing the primary comparison link`);
    assert.match(primary,/>油溫補償<\/a>/,`${page} is missing the primary temperature link`);

    const menu=nav.match(/<details class="navMore"><summary>更多頁面<\/summary><div class="navMenu">([\s\S]*?)<\/div><\/details>/)?.[1];
    assert.ok(menu,`${page} is missing the more-pages menu`);
    assert.equal((menu.match(/<a\b/g)||[]).length,7,`${page} must fold seven secondary links into the menu`);
    assert.doesNotMatch(menu,/temperature\.html/,`${page} must expose temperature outside the menu`);
    assert.equal((nav.match(/aria-current="page"/g)||[]).length,1,`${page} must identify exactly one current page`);
  }
});
