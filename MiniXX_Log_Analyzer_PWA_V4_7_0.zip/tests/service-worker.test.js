import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
const origin='https://preview.example';
const scope=`${origin}/analyzer/`;
const currentCache=source.match(/const CACHE\s*=\s*['"]([^'"]+)/)?.[1];
const version=source.match(/const VERSION\s*=\s*['"]([^'"]+)/)?.[1];
const absolute=value=>new URL(typeof value==='string'?value:value.url??value.href,scope).href;
const publicPages=[
  'index.html','compare.html','temperature.html','compression.html','guide.html','tuning.html','faq.html','privacy.html',
  'articles.html','about.html','articles/log-quality.html','articles/afr-basics.html','articles/fuel-cl.html',
  'articles/methodology.html','articles/fuel-step-case.html','articles/compare-logs.html','articles/ignition-map.html','articles/screenshot-map.html','articles/troubleshooting.html'
];

function worker(network=async()=>{throw new Error('offline');}){
  const handlers=new Map();
  const stores=new Map();
  const deleted=[];
  const requests=[];
  const installed=[];
  let claimed=false;
  class WorkerRequest extends Request{
    constructor(input,options){super(absolute(input),options);}
  }
  async function open(name){
    if(!stores.has(name))stores.set(name,new Map());
    const entries=stores.get(name);
    return {
      async put(request,response){entries.set(absolute(request),response.clone());},
      async match(request,options={}){
        const url=new URL(absolute(request));
        for(const [key,response]of entries){
          const candidate=new URL(key);
          if(key===url.href||options.ignoreSearch&&candidate.origin===url.origin&&candidate.pathname===url.pathname)return response.clone();
        }
      },
      async addAll(assets){installed.push(...assets);},
      async keys(){return [...entries.keys()].map(key=>new WorkerRequest(key));}
    };
  }
  const caches={
    open,
    async keys(){return [...stores.keys()];},
    async delete(name){deleted.push(name);return stores.delete(name);},
    async match(request,options){
      for(const name of stores.keys()){
        const response=await(await open(name)).match(request,options);
        if(response)return response;
      }
    }
  };
  vm.runInNewContext(source,{
    self:{
      location:new URL(`${scope}sw.js`),
      registration:{scope},
      addEventListener(type,handler){handlers.set(type,handler);},
      async skipWaiting(){},
      clients:{async claim(){claimed=true;}}
    },
    caches,URL,Request:WorkerRequest,Response,
    async fetch(request,options){
      requests.push({url:absolute(request),cache:options?.cache??request.cache});
      return network(request,options);
    }
  });
  return {
    caches,deleted,requests,installed,
    get claimed(){return claimed;},
    async dispatch(type,request){
      const pending=[];
      let response;
      handlers.get(type)({request,waitUntil(promise){pending.push(promise);},respondWith(promise){response=Promise.resolve(promise);}});
      const result=await response;
      await Promise.all(pending);
      return result;
    }
  };
}

const navigation=path=>({url:absolute(path),method:'GET',mode:'navigate'});

test('online navigation revalidates HTML and replaces the stale cached page',async()=>{
  const app=worker(async()=>new Response('new navigation'));
  const request=navigation(`compare.html?${version}`);
  const cache=await app.caches.open(currentCache);
  await cache.put(request,new Response('old two-link navigation'));
  assert.equal(await(await app.dispatch('fetch',request)).text(),'new navigation');
  assert.equal(app.requests[0].cache,'no-cache');
  assert.equal(await(await cache.match(request)).text(),'new navigation');
});

test('offline navigation uses the same page from the current cache across version queries',async()=>{
  const app=worker();
  const old=await app.caches.open('minixx-log-old-preview');
  await old.put('compare.html?v=old',new Response('obsolete comparison'));
  const cache=await app.caches.open(currentCache);
  await cache.put(`index.html?${version}`,new Response('analysis homepage'));
  await cache.put(`compare.html?${version}`,new Response('current comparison'));
  const response=await app.dispatch('fetch',navigation('compare.html?v=old'));
  assert.equal(await response.text(),'current comparison');
});

test('offline missing pages are not replaced with an unrelated analysis homepage',async()=>{
  const app=worker();
  const cache=await app.caches.open(currentCache);
  await cache.put(`index.html?${version}`,new Response('analysis homepage'));
  const response=await app.dispatch('fetch',navigation('missing.html'));
  assert.equal(response.status,503);
  assert.notEqual(await response.text(),'analysis homepage');
});

test('activation removes only older analyzer caches and claims clients',async()=>{
  const app=worker();
  await app.caches.open('another-app-cache');
  await app.caches.open('minixx-log-old-preview');
  await app.caches.open(currentCache);
  await app.dispatch('activate');
  assert.deepEqual(app.deleted,['minixx-log-old-preview']);
  assert.deepEqual(await app.caches.keys(),['another-app-cache',currentCache]);
  assert.equal(app.claimed,true);
});

test('installation reloads precached pages and assets instead of reusing HTTP cache',async()=>{
  const app=worker();
  await app.dispatch('install');
  assert.ok(app.installed.length>0);
  for(const request of app.installed)assert.equal(request.cache,'reload',absolute(request));
  for(const page of publicPages)assert.ok(app.installed.some(request=>absolute(request).includes(`/${page}?`)),`${page} is not precached`);
  assert.ok(app.installed.every(request=>!absolute(request).includes('cloudflareinsights.com')),'third-party analytics must not be precached');
});

test('cross-origin analytics requests are ignored by the service worker',async()=>{
  const app=worker(async()=>new Response('network should not be called'));
  const response=await app.dispatch('fetch',{url:'https://static.cloudflareinsights.com/beacon.min.js',method:'GET',mode:'no-cors'});
  assert.equal(response,undefined);
  assert.equal(app.requests.length,0);
  assert.deepEqual(await app.caches.keys(),[]);
});
