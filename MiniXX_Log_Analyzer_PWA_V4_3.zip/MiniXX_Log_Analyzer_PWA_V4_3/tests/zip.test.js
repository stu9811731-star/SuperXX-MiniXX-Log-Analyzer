import test from 'node:test';
import assert from 'node:assert/strict';
import {unzipLoga} from '../src/zip.js';

function eocd({entries=0,centralOffset=0}={}){
  const bytes=new Uint8Array(22),view=new DataView(bytes.buffer);
  view.setUint32(0,0x06054b50,true);
  view.setUint16(8,entries,true);view.setUint16(10,entries,true);
  view.setUint32(16,centralOffset,true);
  return bytes.buffer;
}

test('rejects oversized or malformed ZIP archives before extraction',async()=>{
  await assert.rejects(unzipLoga(new ArrayBuffer(25*1024*1024+1)),/25 MB/);
  await assert.rejects(unzipLoga(new ArrayBuffer(22)),/無法辨識 ZIP 結構/);
  await assert.rejects(unzipLoga(eocd({entries:101})),/項目過多/);
  await assert.rejects(unzipLoga(eocd({entries:1,centralOffset:23})),/中央目錄位置無效/);
});

test('rejects an empty ZIP instead of silently succeeding',async()=>{
  await assert.rejects(unzipLoga(eocd()),/找不到支援的 Log/);
});
