import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const pages=[
  'index.html','compare.html','guide.html','tuning.html','faq.html','privacy.html',
  'articles.html','about.html','articles/log-quality.html','articles/afr-basics.html',
  'articles/fuel-cl.html','articles/fuel-step-case.html','articles/compare-logs.html',
  'articles/ignition-map.html','articles/screenshot-map.html','articles/troubleshooting.html'
];

test('all content pages have unique titles and working local page links',()=>{
  const titles=new Set();
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const title=html.match(/<title>([^<]+)<\/title>/)?.[1];
    assert.ok(title,`${page} is missing a title`);
    assert.ok(!titles.has(title),`${page} duplicates title ${title}`);
    titles.add(title);

    for(const [,href] of html.matchAll(/href="([^"]+)"/g)){
      if(!href.startsWith('.')||href.startsWith('..')&&href.includes('://'))continue;
      const withoutQuery=href.split(/[?#]/)[0];
      if(!withoutQuery||!withoutQuery.endsWith('.html'))continue;
      assert.ok(existsSync(resolve(root,dirname(page),withoutQuery)),`${page} links to missing ${href}`);
    }
  }
});

test('article pages do not include ad units inside instructional content',()=>{
  for(const page of pages.filter(page=>page==='articles.html'||page.startsWith('articles/'))){
    const html=readFileSync(resolve(root,page),'utf8');
    assert.doesNotMatch(html,/adsbygoogle|pagead2\.googlesyndication\.com/);
  }
});

test('every public page uses the same XXFueL header brand',()=>{
  for(const page of pages){
    const html=readFileSync(resolve(root,page),'utf8');
    const headerBrand=html.match(/<header[^>]*>[\s\S]*?<p class="eyebrow brandEyebrow">([^<]+)<\/p>/)?.[1];
    assert.equal(headerBrand,'XXFueL',`${page} has an inconsistent header brand`);
    assert.match(html,/<title>[^<]*(?:｜XXFueL|XXFueL｜)[^<]*<\/title>/,`${page} title does not use XXFueL consistently`);
  }
});
