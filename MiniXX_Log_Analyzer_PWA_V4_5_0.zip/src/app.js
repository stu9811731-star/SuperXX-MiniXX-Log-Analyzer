import {parseLogText, analyzeLogs, analyzeIgnition, reportToCsv, ignitionToCsv} from './analyzer.js?v=4.5.0';
import {unzipLoga} from './zip.js?v=4.5.0';
import {initScreenshotMap,getCurrentFuelValue,adjustmentLabel,adjustedFuelValue,finalFuelValue} from './screenshot-map.js?v=4.5.0';

const $ = s => document.querySelector(s);
const filesEl=$('#files'), drop=$('#drop'), runBtn=$('#run'), result=$('#result'), statusEl=$('#status');
const baseFuelInput=$('#baseFuel'), baseFuelRange=$('#baseFuelRange');
let selected=[]; let latestReport=null; let latestIgnitionReport=null;
const MAX_FILES = 20, MAX_FILE_BYTES = 25 * 1024 * 1024;
const MAX_TOTAL_FILE_BYTES = 100 * 1024 * 1024, MAX_TOTAL_ROWS = 500000;

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function setStatus(s, bad=false){statusEl.textContent=s;statusEl.className=bad?'bad':'';}
function syncBaseFuel(source){
  const value=Number(source.value);
  if(!Number.isFinite(value))return;
  if(source===baseFuelRange)baseFuelInput.value=String(value);
  else if(value>=50&&value<=150)baseFuelRange.value=String(value);
  if(latestReport&&value>=50&&value<=150){latestReport.settings.baseFuelPct=value;renderFuelMap(latestReport);}
}
baseFuelRange.addEventListener('input',()=>syncBaseFuel(baseFuelRange));
baseFuelInput.addEventListener('input',()=>syncBaseFuel(baseFuelInput));
function updateFiles(){
  $('#fileList').innerHTML=selected.length?selected.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇檔案';
  runBtn.disabled=!selected.length;
}
function selectFiles(files) {
  const next = [...files];
  if (next.length > MAX_FILES) { selected=[]; updateFiles(); setStatus(`一次最多可匯入 ${MAX_FILES} 個 Log`,true); return; }
  for (const file of next) {
    if (!/\.(?:loga|log|txt|csv|zip)$/i.test(file.name)) { selected=[]; updateFiles(); setStatus('支援 .loga / .log / .txt / .csv / .zip',true); return; }
    if (file.size > MAX_FILE_BYTES) { selected=[]; updateFiles(); setStatus(`${file.name} 超過 25 MB 上限`,true); return; }
  }
  if (next.reduce((total,file)=>total+file.size,0) > MAX_TOTAL_FILE_BYTES) {
    selected=[]; updateFiles(); setStatus('Log 總容量超過 100 MB 上限',true); return;
  }
  selected=next; updateFiles(); setStatus('');
}
filesEl.addEventListener('change',()=>selectFiles(filesEl.files));
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add('drag');}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove('drag');}));
drop.addEventListener('drop',e=>selectFiles(e.dataTransfer.files));
drop.addEventListener('click',()=>filesEl.click());
drop.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();filesEl.click();}});

function getSettings(){ return {
  ecuModel:'MiniXX',
  logPlatform:$('#logPlatform').value,
  fuelClMode:$('#fuelClMode').value,
  baseFuelPct:Number($('#baseFuel').value),
  minEngineTemp:Number($('#minTemp').value),
  entryWaitSeconds:Number($('#entryWait').value),
  minStableSecondsAfterWait:Number($('#minStable').value),
  minSamplesPerCell:Number($('#minSamples').value),
  accExclusionSeconds:Number($('#accWait').value),
  maxSuggestionPct:Number($('#maxSuggest').value)
}; }

async function loadSelected(){
  const logs=[]; let totalRows=0;
  const addLog=(name,text)=>{
    const rows=parseLogText(text,name);
    totalRows+=rows.length;
    if(totalRows>MAX_TOTAL_ROWS)throw new Error('Log 解析後總資料超過 500,000 列上限；請分批分析。');
    logs.push({name,rows,platform:rows.meta?.platform??'unknown'});
  };
  for (const f of selected) {
    if (/\.zip$/i.test(f.name)) {
      const entries=await unzipLoga(await f.arrayBuffer());
      for (const e of entries) addLog(`${f.name}/${e.name}`,e.text);
    } else addLog(f.name,await f.text());
  }
  return logs;
}

function fmt(v,n=2){return v==null?'—':Number(v).toFixed(n);}
function signed(v,n=1){if(v==null)return'—';const x=Number(v);return `${x>0?'+':''}${x.toFixed(n)}%`;}
function badge(v){return `<span class="badge ${String(v).toLowerCase().replaceAll(' ','-')}">${esc(v)}</span>`;}

function renderFuelMap(report){
  const metric=$('#mapMetric').value;
  const baseFuelPct=report.settings.baseFuelPct??100;
  const rpmAxis=report.axes.fuelRpmAxis;
  const tpsAxis=report.axes.fuelTpsAxis;
  const by=new Map(report.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  let h=`<table class="map"><caption class="srOnly">MiniXX 燃油分析圖</caption><thead><tr><th>TPS\\RPM</th>`+rpmAxis.map(r=>`<th>${r}</th>`).join('')+'</tr></thead><tbody>';
  for(const tps of tpsAxis){
    h+=`<tr><th>${tps}%</th>`;
    for(const rpm of rpmAxis){
      const c=by.get(`${tps}|${rpm}`);
      if(!c){h+='<td class="empty">—</td>';continue;}
      if(metric==='correction' && c.status!=='Adjust'){
        h+=`<td class="empty" title="此格沒有可執行的燃油修改建議；狀態 ${esc(c.status)}；可信度 ${esc(c.confidence)}；N=${c.samples}">—</td>`;
        continue;
      }
      const cls=metric==='correction'?`confidence-${c.confidence.toLowerCase()}`:'';
      let main='—',sub='';
      if(metric==='actualAfr'){
        main=fmt(c.actualAfrMedian,2);sub=`目標 ${fmt(c.targetAfrMedian,2)} · N=${c.samples}`;
      }else if(metric==='targetAfr'){
        main=fmt(c.targetAfrMedian,2);sub=`實際 ${fmt(c.actualAfrMedian,2)} · N=${c.samples}`;
      }else{
        const current=getCurrentFuelValue(c.tps,c.rpm);
        if(c.status==='Adjust'){
          if(current==null){
            main=`空燃比差異 ${signed(c.afrResidualCorrectionPct,1)}`;
            sub=`實際 ${fmt(c.actualAfrMedian,2)}／目標 ${fmt(c.targetAfrMedian,2)} · N=${c.samples}`;
          }else{
            main=adjustmentLabel(c.suggestedCorrectionPct);
            const adjustedGlobal=adjustedFuelValue(current,c.suggestedCorrectionPct);
            const currentFinal=finalFuelValue(current,baseFuelPct);
            const adjustedFinal=finalFuelValue(adjustedGlobal,baseFuelPct);
            sub=`全域 ${current.toFixed(1)}→${adjustedGlobal.toFixed(1)} · 最終供油 ${currentFinal.toFixed(1)}→${adjustedFinal.toFixed(1)}`;
          }
        }
      }
      h+=`<td class="${cls}" title="Target ${c.targetAfrMedian} / Actual ${c.actualAfrMedian}; AFR difference ${c.afrResidualCorrectionPct}%; fuel correction ${c.theoreticalCorrectionPct}%; n=${c.samples}; confidence ${esc(c.confidence)}; Fuel_CL raw ${c.fuelClMedian ?? '—'}">`+
        `<strong>${main}</strong><small>${sub}</small></td>`;
    }
    h+='</tr>';
  }
  h+='</tbody></table>';
  $('#mapWrap').innerHTML=h;
}

initScreenshotMap({onChange:()=>{if(latestReport)renderFuelMap(latestReport);}});

export function render(report, ignitionReport){
  latestReport=report; latestIgnitionReport=ignitionReport; result.hidden=false;
  const s=report.summary;
  $('#summary').innerHTML=
    `<div><b>${s.cells}</b><span>有效格位</span></div>`+
    `<div><b>${s.adjustCells}</b><span>顯示修正</span></div>`+
    `<div><b>${s.verifyCells}</b><span>需驗證</span></div>`+
    `<div><b>${s.highConfidenceCells}</b><span>高可信格位</span></div>`+
    `<div><b>${s.totalSamples}</b><span>有效樣本</span></div>`+
    `<div><b>${fmt(s.effectiveSeconds,1)}s</b><span>有效時間</span></div>`;

  $('#fuelGridNote').textContent=`${report.platformSummary.join(' + ')} · MiniXX Fuel Map ${report.grid.fuel}。基礎油量 ${report.settings.baseFuelPct}%；最終供油＝全域燃油 × 基礎油量 ÷ 100。${report.calculationMode}；±${report.settings.correctionDeadbandPct}% 內保留原值，達 ${report.settings.extremeCorrectionPct}% 不直接修改。`;
  renderFuelMap(report);

  $('#detailBody').innerHTML=report.cells.map(c=>`<tr>`+
    `<td>${c.tps}%</td><td>${c.rpm}</td>`+
    `<td>${fmt(c.targetAfrMedian,2)}</td><td>${fmt(c.actualAfrMedian,2)}</td>`+
    `<td>${c.samples}</td><td>${fmt(c.effectiveN,1)}</td><td>${fmt(c.effectiveSeconds,1)}</td><td>${c.segments}</td>`+
    `<td>${signed(c.afrResidualCorrectionPct,1)}</td><td>${signed(c.medianCorrectionPct,1)}</td><td>${signed(c.weightedCorrectionPct,1)}</td>`+
    `<td><b>${signed(c.theoreticalCorrectionPct,1)}</b></td><td>${signed(c.safetyBandCorrectionPct,1)}</td>`+
    `<td><b>${c.status==='Adjust'?signed(c.suggestedCorrectionPct,1):'—'}</b></td>`+
    `<td>${fmt(c.fuelClMedian,1)}</td><td>${c.fuelClIncluded?'已納入':'未納入'}</td>`+
    `<td>${badge(c.confidence)}</td><td>${badge(c.consistency)}</td><td>${badge(c.status)}</td>`+
    `</tr>`).join('');

  const d=report.diagnostics||{};
  $('#diagnostics').innerHTML=[
    ['原始資料',d.rawRows],['溫度 ≥ 門檻',d.tempPass],['AFR/WBO2 合格',d.afrPass],
    ['非加速補油當下',d.accelPass],['品質閘門通過',d.gatePass],['進格等待後',d.afterEntryWait],
    ['最終有效樣本',d.acceptedSamples]
  ].map(([k,v])=>`<div><span>${esc(k)}</span><b>${v??0}</b></div>`).join('');

  const labels={
    engine_temp:'低於引擎溫度門檻',afr_missing:'AFR 資料缺失',wbo2_range:'WBO2 超出合理範圍',
    wbo2_not_ready:'WBO2 未就緒',fuel_cut:'斷油 / FuelPW≈0',after_acc_fuel:'加速補油後排除',
    fuel_cl_missing:'Fuel_CL 缺失',fuel_cl_range:'Fuel_CL 無法換算',
    out_of_axis:'超出 ECU 分析軸範圍',entry_wait:'進格等待',short_segment:'等待後有效時間不足'
  };
  $('#quality').innerHTML=Object.entries(report.exclusions).map(([k,v])=>`<div><span>${esc(labels[k]||k)}</span><b>${v}</b></div>`).join('');

  $('#anomalies').innerHTML=report.anomalies.length?report.anomalies.map(a=>{
    const type=({multi_log_mismatch:'多 Log 不一致',extreme_correction:'偏差達 11%，禁止直接修改',fuel_cl_safety_limit:'Fuel_CL 超過保守安全門檻'})[a.type]||a.type;
    return `<div class="alert"><b>${a.tps}% / ${a.rpm} rpm</b> — ${esc(type)}（燃油修正 ${signed(a.value,1)}${a.fuelClMedian!=null?`；Fuel_CL raw ${fmt(a.fuelClMedian,1)}`:''}）</div>`;
  }).join(''):'<div class="ok">未偵測到 ≥11% 極端偏差、Fuel_CL 超限或多 Log 明顯衝突。</div>';

  renderIgnition(ignitionReport);
}

function renderIgnition(report){
  const model=report.settings.ecuModel;
  const pressureMode=$('#ignitionMetric').value==='map';
  $('#ignitionTitle').textContent=`${model} ${pressureMode?'進氣歧管壓力':'實際點火角'}（${report.grid}）`;
  $('#ignitionNote').textContent=pressureMode
    ? '顯示同一批暖機後點火樣本中的 Cyl1_Eng_AP／MAP 原始絕對壓力；MiniXX Android Log 以 kPa abs 顯示，不是已扣除大氣壓的正負壓。'
    : '依暖機後 Log 的 SA 欄位顯示記錄當下的實際點火角，不等同基礎點火表；請以 SpeedTuningX 的欄位定義為準。';

  const s=report.summary;
  $('#ignitionSummary').innerHTML=
    `<div><span>Log 總樣本</span><b>${s.inputRows}</b></div>`+
    `<div><span>有效 SA 樣本</span><b>${s.acceptedRows}</b></div>`+
    `<div><span>有效 MAP 樣本</span><b>${s.acceptedMapRows}</b></div>`+
    `<div><span>有資料格位</span><b>${s.cells}</b></div>`+
    `<div><span>有 MAP 格位</span><b>${s.cellsWithMap}</b></div>`+
    `<div><span>缺少 SA</span><b>${s.exclusions.missingSa}</b></div>`+
    `<div><span>未達暖機溫度</span><b>${s.exclusions.engineTemp}</b></div>`;

  const detailBody=$('#ignitionDetailBody');
  $('#exportIgnition').disabled=!report.cells.length;
  if(!report.cells.length){
    $('#ignitionMapWrap').innerHTML='<div class="alert">Log 缺少 SA／點火角資料，或資料未達引擎最低溫度，無法顯示實際點火角。</div>';
    detailBody.innerHTML='';
    return;
  }

  const by=new Map(report.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  if(pressureMode&&!s.cellsWithMap){
    $('#ignitionMapWrap').innerHTML='<div class="alert">這份 Log 缺少 Cyl1_Eng_AP／MAP 欄位，無法顯示進氣歧管壓力；仍可切回實際點火角。</div>';
  }else{
    let h=`<table class="map ignitionMap"><caption class="srOnly">${esc(model)} ${pressureMode?'進氣歧管壓力':'實際點火角'}分布圖</caption><thead><tr><th>TPS\\RPM</th>`+report.axes.rpmAxis.map(r=>`<th>${r}</th>`).join('')+'</tr></thead><tbody>';
    for(const tps of report.axes.tpsAxis){
      h+=`<tr><th>${tps}%</th>`;
      for(const rpm of report.axes.rpmAxis){
        const c=by.get(`${tps}|${rpm}`);
        if(!c||(pressureMode&&!c.mapSamples)){h+='<td class="empty">—</td>';continue;}
        h+=pressureMode
          ? `<td class="ignitionCell pressureCell" title="MAP median ${c.mapMedian}; mean ${c.mapMean}; range ${c.mapMin}–${c.mapMax}; n=${c.mapSamples}"><strong>${fmt(c.mapMedian,1)}</strong><small>${fmt(c.mapMin,1)}–${fmt(c.mapMax,1)} kPa</small><small>N=${c.mapSamples}</small></td>`
          : `<td class="ignitionCell" title="Median ${c.actualSaMedian}°; mean ${c.actualSaMean}°; range ${c.actualSaMin}–${c.actualSaMax}°; n=${c.samples}"><strong>${fmt(c.actualSaMedian,1)}°</strong><small>${fmt(c.actualSaMin,1)}–${fmt(c.actualSaMax,1)}°</small><small>N=${c.samples}</small></td>`;
      }
      h+='</tr>';
    }
    h+='</tbody></table>';
    $('#ignitionMapWrap').innerHTML=h;
  }

  detailBody.innerHTML=report.cells.map(c=>`<tr>`+
    `<td>${c.tps}%</td><td>${c.rpm}</td><td><b>${fmt(c.actualSaMedian,2)}°</b></td>`+
    `<td>${fmt(c.actualSaMean,2)}°</td><td>${fmt(c.actualSaMin,2)}°</td><td>${fmt(c.actualSaMax,2)}°</td>`+
    `<td>${fmt(c.actualSaStdDev,2)}°</td><td>${fmt(c.mapMedian,2)}</td><td>${fmt(c.mapMean,2)}</td>`+
    `<td>${fmt(c.mapMin,2)}</td><td>${fmt(c.mapMax,2)}</td><td>${c.mapSamples}</td>`+
    `<td>${c.samples}</td><td>${fmt(c.effectiveSeconds,1)}</td>`+
    `</tr>`).join('');
}

export function showView(view){
  const fuel=view==='fuel';
  $('#fuelView').hidden=!fuel;
  $('#ignitionView').hidden=fuel;
  $('#fuelTab').classList.toggle('active',fuel);
  $('#ignitionTab').classList.toggle('active',!fuel);
  $('#fuelTab').setAttribute('aria-selected',String(fuel));
  $('#ignitionTab').setAttribute('aria-selected',String(!fuel));
  $('#fuelTab').tabIndex=fuel?0:-1;
  $('#ignitionTab').tabIndex=fuel?-1:0;
}

$('#fuelTab').addEventListener('click',()=>showView('fuel'));
$('#ignitionTab').addEventListener('click',()=>showView('ignition'));
$('.resultTabs').addEventListener('keydown',e=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  e.preventDefault();
  const next=(e.key==='ArrowLeft'||e.key==='Home')?'fuel':'ignition';
  showView(next);
  $(next==='fuel'?'#fuelTab':'#ignitionTab').focus();
});

$('#mapMetric').addEventListener('change',()=>{if(latestReport)renderFuelMap(latestReport);});
$('#ignitionMetric').addEventListener('change',()=>{if(latestIgnitionReport)renderIgnition(latestIgnitionReport);});
$('#fuelClMode').addEventListener('change',()=>{
  if(result.hidden)return;
  result.hidden=true;latestReport=null;latestIgnitionReport=null;
  setStatus('Fuel_CL 計算方式已變更，請重新執行分析。');
});
$('#logPlatform').addEventListener('change',()=>{
  if(result.hidden)return;
  result.hidden=true;latestReport=null;latestIgnitionReport=null;
  setStatus('Log 系統設定已變更，請重新執行分析。');
});

runBtn.addEventListener('click',async()=>{
  runBtn.disabled=true;setStatus('正在辨識 Log 系統並執行 V4.4.2 分析…');
  try{
    const logs=await loadSelected();
    const settings=getSettings();
    const report=analyzeLogs(logs,settings);
    const ignitionReport=analyzeIgnition(logs,settings);
    render(report,ignitionReport);
    showView('fuel');
    setStatus(`完成：${report.platformSummary.join(' + ')} · MiniXX · ${logs.length} 個 Log，${report.summary.cells} 個有效格位，${report.summary.adjustCells} 格建議修正`);
  }catch(e){console.error(e);setStatus(e.message||String(e),true);}
  finally{runBtn.disabled=false;}
});

$('#export').addEventListener('click',()=>{
  if(!latestReport)return;
  const blob=new Blob(['\uFEFF'+reportToCsv(latestReport)],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='minixx_fuel_analysis_v4_4_2.csv';a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});

$('#exportIgnition').addEventListener('click',()=>{
  if(!latestIgnitionReport)return;
  const blob=new Blob(['\uFEFF'+ignitionToCsv(latestIgnitionReport)],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='minixx_ignition_map_pressure_v4_4_2.csv';a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});

let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;$('#install').hidden=false;});
$('#install').addEventListener('click',async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$('#install').hidden=true;});
if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js?v=4.5.0').catch(console.warn);
