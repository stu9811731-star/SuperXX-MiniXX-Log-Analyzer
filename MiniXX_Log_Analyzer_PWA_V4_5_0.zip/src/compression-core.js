const number = (value, label) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) throw new TypeError(`${label}必須是有效數字`);
  return parsed;
};

export function roundVolumeCc(diameterMm, heightMm) {
  return Math.PI * Math.pow(diameterMm, 2) / 4 * heightMm / 1000;
}

export function calculateCompressionRatio(input) {
  const boreMm = number(input.boreMm, '缸徑');
  const strokeMm = number(input.strokeMm, '行程');
  const chamberCc = number(input.chamberCc, '燃燒室容積');
  const pistonCc = number(input.pistonCc, '活塞頂容積');
  const gasketBoreMm = number(input.gasketBoreMm, '墊片孔徑');
  const gasketThicknessMm = number(input.gasketThicknessMm, '墊片壓縮厚度');
  const deckMm = number(input.deckMm, '上止點間隙');
  const cylinders = number(input.cylinders, '汽缸數');

  if (boreMm <= 0 || strokeMm <= 0) throw new RangeError('缸徑與行程必須大於 0');
  if (chamberCc < 0 || gasketThicknessMm < 0) throw new RangeError('燃燒室與墊片厚度不可小於 0');
  if (gasketBoreMm <= 0) throw new RangeError('墊片孔徑必須大於 0');
  if (!Number.isInteger(cylinders) || cylinders < 1 || cylinders > 16) throw new RangeError('汽缸數必須是 1～16 的整數');

  const sweptCc = roundVolumeCc(boreMm, strokeMm);
  const gasketCc = roundVolumeCc(gasketBoreMm, gasketThicknessMm);
  const deckCc = roundVolumeCc(boreMm, deckMm);
  const clearanceCc = chamberCc + pistonCc + gasketCc + deckCc;

  if (clearanceCc <= 0) throw new RangeError('餘隙容積必須大於 0，請檢查活塞頂與上止點間隙的正負值');

  return {
    ratio: (sweptCc + clearanceCc) / clearanceCc,
    sweptCc,
    totalDisplacementCc: sweptCc * cylinders,
    clearanceCc,
    chamberCc,
    pistonCc,
    gasketCc,
    deckCc,
    cylinders
  };
}
