import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateCompressionRatio,roundVolumeCc} from '../src/compression-core.js';

test('round cylinder volume converts cubic millimetres to cc',()=>{
  assert.ok(Math.abs(roundVolumeCc(63,57.9)-180.49)<0.02);
});

test('compression ratio includes chamber, piston, gasket and deck volumes',()=>{
  const result=calculateCompressionRatio({
    boreMm:63,strokeMm:57.9,cylinders:1,chamberCc:16,pistonCc:1.5,
    gasketBoreMm:64,gasketThicknessMm:0.5,deckMm:0.2
  });
  assert.ok(Math.abs(result.ratio-10.16)<0.02);
  assert.ok(Math.abs(result.totalDisplacementCc-result.sweptCc)<0.001);
});

test('negative piston dome and above-deck values reduce clearance volume',()=>{
  const base={boreMm:63,strokeMm:57.9,cylinders:1,chamberCc:18,pistonCc:0,gasketBoreMm:64,gasketThicknessMm:0.5,deckMm:0};
  const flat=calculateCompressionRatio(base);
  const dome=calculateCompressionRatio({...base,pistonCc:-1,deckMm:-0.1});
  assert.ok(dome.clearanceCc<flat.clearanceCc);
  assert.ok(dome.ratio>flat.ratio);
});

test('total displacement follows cylinder count without changing ratio',()=>{
  const input={boreMm:86,strokeMm:86,cylinders:4,chamberCc:48,pistonCc:0,gasketBoreMm:87,gasketThicknessMm:0.8,deckMm:0.1};
  const result=calculateCompressionRatio(input);
  assert.ok(Math.abs(result.totalDisplacementCc-result.sweptCc*4)<0.001);
});

test('invalid dimensions and non-positive clearance are rejected',()=>{
  const valid={boreMm:63,strokeMm:57.9,cylinders:1,chamberCc:16,pistonCc:0,gasketBoreMm:64,gasketThicknessMm:0.5,deckMm:0};
  assert.throws(()=>calculateCompressionRatio({...valid,boreMm:0}),/大於 0/);
  assert.throws(()=>calculateCompressionRatio({...valid,cylinders:1.5}),/整數/);
  assert.throws(()=>calculateCompressionRatio({...valid,chamberCc:0,pistonCc:-3,gasketThicknessMm:0}),/餘隙容積/);
});
