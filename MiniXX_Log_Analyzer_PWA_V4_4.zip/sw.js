const CACHE='minixx-log-v4.4.0';
const VERSION='v=4.4.0';
const ASSETS=[
  './',
  `./index.html?${VERSION}`,
  `./compare.html?${VERSION}`,
  `./guide.html?${VERSION}`,
  `./tuning.html?${VERSION}`,
  `./faq.html?${VERSION}`,
  `./privacy.html?${VERSION}`,
  `./styles.css?${VERSION}`,
  `./views.css?${VERSION}`,
  `./manifest.webmanifest?${VERSION}`,
  `./src/app.js?${VERSION}`,
  `./src/compare.js?${VERSION}`,
  `./src/faq.js?${VERSION}`,
  `./src/analyzer.js?${VERSION}`,
  `./src/zip.js?${VERSION}`,
  `./src/screenshot-map.js?${VERSION}`,
  `./vendor/tesseract/tesseract.min.js?${VERSION}`,
  './vendor/tesseract/worker.min.js',
  './assets/icon-log.svg',
  './assets/icon-log-192.svg'
];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  if(new URL(event.request.url).origin!==self.location.origin)return;

  if(event.request.mode==='navigate'){
    event.respondWith(
      fetch(event.request)
        .then(response=>{
          if(response.ok){
            const copy=response.clone();
            caches.open(CACHE).then(cache=>cache.put(event.request,copy));
          }
          return response;
        })
        .catch(()=>caches.match(event.request).then(cached=>cached||caches.match(`./index.html?${VERSION}`)))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
      if(response.ok){
        const copy=response.clone();
        caches.open(CACHE).then(cache=>cache.put(event.request,copy));
      }
      return response;
    }))
  );
});
