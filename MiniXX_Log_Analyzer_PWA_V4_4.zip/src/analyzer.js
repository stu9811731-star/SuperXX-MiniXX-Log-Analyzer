const MINIXX_FUEL_RPM_20 = [800,1600,2400,3200,4000,4800,5600,6400,7200,8000,8800,9600,10400,11200,12000,12800,13600,14400,15200,16000];
const MINIXX_IGN_RPM_20 = [800,1600,2400,3200,4000,4800,5600,6400,7200,8000,8800,9600,10400,11200,12000,12800,13600,14400,15200,16000];
const MINIXX_FUEL_TPS_17 = [0,2,4,6,8,10,15,20,25,30,40,50,60,70,80,90,100];
const MINIXX_IGN_TPS_9 = [0,2,5,10,20,40,60,80,100];

export const ECU_PROFILES = {
  MiniXX: {
    name:'MiniXX', fuelGrid:'20×17', ignitionGrid:'20×9', variableAxes:false,
    fuelRpmAxis:MINIXX_FUEL_RPM_20, fuelTpsAxis:MINIXX_FUEL_TPS_17,
    ignitionRpmAxis:MINIXX_IGN_RPM_20, ignitionTpsAxis:MINIXX_IGN_TPS_9
  }
};

export function getEcuProfile(model='MiniXX') {
  const profile=ECU_PROFILES[model];
  if (!profile) throw new Error(`不支援的 ECU 型號：${model}`);
  return profile;
}

export const PRESET = {
  name: 'MiniXX',
  fuelTpsAxis: MINIXX_FUEL_TPS_17,
  afrIgnTpsAxis: MINIXX_IGN_TPS_9,
  rpmAxis: MINIXX_FUEL_RPM_20
};

export const DEFAULT_SETTINGS = {
  ecuModel: 'MiniXX',
  logPlatform: 'auto',
  fuelClMode: 'off',
  minEngineTemp: 65,
  accExclusionSeconds: 1.0,
  entryWaitSeconds: 0.5,
  minStableSecondsAfterWait: 1.0,
  minSamplesPerCell: 20,
  maxSuggestionPct: 5,
  suggestionStepPct: 0.8,
  minAfr: 8,
  maxAfr: 25,
  accFuelTolerance: 0.002,
  fuelClSafetyThreshold: 20,
  fuelClStateEpsilon: 0.05,
  correctionDeadbandPct: 3,
  extremeCorrectionPct: 11,
  maxContinuityGapSeconds: 0.5,
  highConfidenceMinSamples: 30,
  minMediumEffectiveN: 12,
  timeUnit: 'auto'
};

const FIELD_ALIASES = {
  time: ['Time','time','Timestamp','timestamp','Sec','Seconds','LogTime'],
  afrTarget: ['AFR_Target','AFR Target','Target_AFR','Target AFR'],
  afrActual: ['AFR_WBO2','AFR WBO2','WBO2_AFR','Wideband_AFR','AFR'],
  fuelCL: ['Fuel_CL','Fuel CL','FuelCL'],
  rpm: ['RPM','Engine_RPM','Eng_RPM'],
  tps: ['TPS_Percent','TPS Percent','TPS','Throttle_Percent'],
  temp: ['T_Eng','T Eng','Engine_Temp','ECT'],
  accFuel: ['Acc_Fuel_Mult','Acc Fuel Mult','Accel_Fuel_Mult'],
  finalVM: ['Cyl1_Final_VM','Final_VM','Cyl1 Final VM'],
  fuelPW: ['Cyl1_Comn_FuelPW','Comn_FuelPW','FuelPW','Injector_PW'],
  map: ['Cyl1_Eng_AP','Eng_AP','MAP','Manifold_Pressure'],
  sa: ['SA','Spark_Angle','Ignition_Angle'],
  wbo2Ready: ['WBO2_Ready','WBO2 Ready','WBO2Ready','Wideband_Ready','AFR_Ready']
};

function normalizeHeader(s) {
  return String(s ?? '').trim().replace(/^\uFEFF/, '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function detectDelimiter(line) {
  const candidates = [',','\t',';'];
  let best = ',', bestCount = -1;
  for (const c of candidates) {
    const n = line.split(c).length;
    if (n > bestCount) { best = c; bestCount = n; }
  }
  return best;
}

function splitDelimited(line, delimiter) {
  const out = [];
  let cur = '', quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i+1] === '"') { cur += '"'; i++; }
      else quoted = !quoted;
    } else if (ch === delimiter && !quoted) {
      out.push(cur); cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out.map(v => v.trim());
}

function parseNum(v) {
  if (v == null || v === '') return null;
  const n = Number(String(v).trim().replace('%',''));
  return Number.isFinite(n) ? n : null;
}

function parseReady(v) {
  if (v == null || v === '') return null;
  const s = String(v).trim().toLowerCase();
  if (['1','true','ready','yes','ok','on'].includes(s)) return true;
  if (['0','false','notready','no','off','invalid'].includes(s)) return false;
  const n = Number(s);
  return Number.isFinite(n) ? n > 0 : null;
}

function median(values) {
  if (!values.length) return null;
  const a = [...values].sort((x,y)=>x-y);
  const m = Math.floor(a.length/2);
  return a.length%2 ? a[m] : (a[m-1]+a[m])/2;
}
function mean(values) { return values.length ? values.reduce((a,b)=>a+b,0)/values.length : null; }
function weightedMean(values, weights) {
  let sw=0, sx=0;
  for (let i=0;i<values.length;i++) {
    const v=values[i], w=weights[i];
    if (!Number.isFinite(v) || !Number.isFinite(w) || w<=0) continue;
    sx += v*w; sw += w;
  }
  return sw>0 ? sx/sw : null;
}
function weightedMedian(values, weights) {
  const pairs=values.map((value,index)=>({value,weight:weights[index]}))
    .filter(x=>Number.isFinite(x.value)&&Number.isFinite(x.weight)&&x.weight>0)
    .sort((a,b)=>a.value-b.value);
  if(!pairs.length)return null;
  const total=pairs.reduce((sum,x)=>sum+x.weight,0);
  let cumulative=0;
  for(const pair of pairs){cumulative+=pair.weight;if(cumulative>=total/2)return pair.value;}
  return pairs[pairs.length-1].value;
}
function weightedMad(values, weights) {
  const center=weightedMedian(values,weights);
  return center==null?null:weightedMedian(values.map(value=>Math.abs(value-center)),weights);
}
function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
function round(x, n=2) { return x == null ? null : Number(x.toFixed(n)); }
function stddev(values) {
  if (values.length < 2) return null;
  const m = mean(values);
  return Math.sqrt(mean(values.map(v => (v-m)**2)));
}

export function temperatureWeight(temp) {
  if (!Number.isFinite(temp)) return 1;
  if (temp >= 90 && temp <= 100) return 1.50;
  if ((temp >= 80 && temp < 90) || (temp > 100 && temp <= 110)) return 1.20;
  if (temp > 110) return 0.85;
  return 1.00;
}

export function detectLogPlatform(text) {
  const sample=String(text??'').slice(0,4096);
  if(/<aRacer\s+MX\s+APP\s+Log\s+File>/i.test(sample))return 'android';
  if(/<aRacer\s+(?:iOS|Apple|Smart)\s+APP\s+Log\s+File>/i.test(sample))return 'apple';
  return 'unknown';
}

export function parseLogText(text, sourceName='log') {
  const platform=detectLogPlatform(text);
  const lines = String(text).replace(/\r/g,'').split('\n').filter(x => x.trim().length);
  if (lines.length < 2) throw new Error(`${sourceName}: 找不到足夠的資料列`);

  let headerIndex = -1, delimiter = ',';
  for (let i=0; i<Math.min(lines.length, 80); i++) {
    const d = detectDelimiter(lines[i]);
    const headers = splitDelimited(lines[i], d).map(normalizeHeader);
    const hasRpm = FIELD_ALIASES.rpm.some(a => headers.includes(normalizeHeader(a)));
    const hasTps = FIELD_ALIASES.tps.some(a => headers.includes(normalizeHeader(a)));
    if (hasRpm && hasTps) { headerIndex = i; delimiter = d; break; }
  }
  if (headerIndex < 0) throw new Error(`${sourceName}: 找不到 RPM/TPS 欄位標題`);

  const rawHeaders = splitDelimited(lines[headerIndex], delimiter);
  const normalized = rawHeaders.map(normalizeHeader);
  const col = {};
  for (const [key, aliases] of Object.entries(FIELD_ALIASES)) {
    col[key] = aliases.map(normalizeHeader).map(a => normalized.indexOf(a)).find(i => i >= 0) ?? -1;
  }
  const required = ['rpm','tps','temp'];
  const missing = required.filter(k => col[k] < 0);
  if (missing.length) throw new Error(`${sourceName}: 缺少必要欄位 ${missing.join(', ')}`);
  const hasFuelFields=col.afrTarget>=0 && col.afrActual>=0;
  const hasIgnitionField=col.sa>=0;
  if (!hasFuelFields && !hasIgnitionField) {
    throw new Error(`${sourceName}: 至少需要 AFR Target/WBO2（燃油分析）或 SA（點火角分析）欄位`);
  }

  const rawRows = [];
  let fallbackTime = 0;
  for (let i=headerIndex+1; i<lines.length; i++) {
    const cells = splitDelimited(lines[i], delimiter);
    if (cells.length < Math.max(...Object.values(col)) + 1) continue;
    const get = k => col[k] >= 0 ? cells[col[k]] : null;
    let t = parseNum(get('time'));
    if (t == null) { t = fallbackTime; fallbackTime += 0.1; }
    const row = {
      sourceName,
      line: i+1,
      time: t,
      afrTarget: parseNum(get('afrTarget')),
      afrActual: parseNum(get('afrActual')),
      fuelCL: parseNum(get('fuelCL')),
      rpm: parseNum(get('rpm')),
      tps: parseNum(get('tps')),
      temp: parseNum(get('temp')),
      accFuel: parseNum(get('accFuel')),
      finalVM: parseNum(get('finalVM')),
      fuelPW: parseNum(get('fuelPW')),
      map: parseNum(get('map')),
      sa: parseNum(get('sa')),
      wbo2Ready: parseReady(get('wbo2Ready'))
    };
    if (row.rpm != null && row.tps != null) rawRows.push(row);
  }
  rawRows.sort((a,b)=>a.time-b.time);
  if (!rawRows.length) throw new Error(`${sourceName}: 沒有可解析的資料`);

  // MiniX .loga commonly records Time in milliseconds (0,100,200...).
  const diffs=[];
  for(let i=1;i<Math.min(rawRows.length,300);i++){
    const d=rawRows[i].time-rawRows[i-1].time;
    if(Number.isFinite(d)&&d>0) diffs.push(d);
  }
  const dtMedian=median(diffs);
  const timeScale=(dtMedian!=null && dtMedian>=10) ? 0.001 : 1;
  if(timeScale!==1) for(const r of rawRows) r.time*=timeScale;
  const androidSectioned=platform==='android'&&lines.some(line=>/^<VAR NAME>$/i.test(line.trim()))&&lines.some(line=>/^<DATA START>$/i.test(line.trim()));
  rawRows.meta={sourceName,platform,format:androidSectioned?'android_mx_loga':'delimited',headerIndex:headerIndex+1,timeScale,rawRows:rawRows.length,medianRawInterval:dtMedian};
  return rawRows;
}

export function nearestAxis(value, axis) {
  if (value == null) return null;
  let best = axis[0], d = Math.abs(value-axis[0]);
  for (let i=1; i<axis.length; i++) {
    const nd = Math.abs(value-axis[i]);
    if (nd < d) { best = axis[i]; d = nd; }
  }
  return best;
}

function nearestAxisInRange(value, axis) {
  if (!Number.isFinite(value) || !axis.length) return null;
  if (axis.length===1) return axis[0];
  const lower=axis[0]-(axis[1]-axis[0])/2;
  const last=axis.length-1;
  const upper=axis[last]+(axis[last]-axis[last-1])/2;
  if (value<lower || value>upper) return null;
  return nearestAxis(value,axis);
}

function rowInterval(rows, i, maxGap=0.5) {
  if (i < rows.length-1) return Math.min(maxGap,Math.max(0, rows[i+1].time - rows[i].time));
  if (i > 0) return Math.min(maxGap,Math.max(0, rows[i].time - rows[i-1].time));
  return 0;
}

function fuelClFactor(value, mode) {
  if (mode === 'off') return 1;
  if (!Number.isFinite(value)) return null;
  if (mode === 'positive_adds') {
    const factor=1+value/100;
    return factor>0?factor:null;
  }
  return null;
}

function fuelClModeLabel(mode) {
  return ({
    off:'不納入（AFR Target／WBO2）',
    positive_adds:'納入（MiniXX：Fuel_CL 正值＝ECU 加油，單位 %）'
  })[mode]??mode;
}

function qualityGate(row, settings, lastAccTime) {
  if (row.temp == null || row.temp < settings.minEngineTemp) return 'engine_temp';
  if (row.afrTarget == null || row.afrActual == null) return 'afr_missing';
  if (row.afrActual < settings.minAfr || row.afrActual > settings.maxAfr) return 'wbo2_range';
  if (row.wbo2Ready === false) return 'wbo2_not_ready';
  if (row.fuelPW != null && row.fuelPW <= 0.001) return 'fuel_cut';
  if (lastAccTime != null && row.time - lastAccTime <= settings.accExclusionSeconds + 1e-9) return 'after_acc_fuel';
  if (settings.fuelClMode !== 'off') {
    if (!Number.isFinite(row.fuelCL)) return 'fuel_cl_missing';
    if (fuelClFactor(row.fuelCL,settings.fuelClMode)==null) return 'fuel_cl_range';
  }
  return null;
}

// 0.8 is the ECU adjustment step. V4.4 first returns the error to the ±3% safety band.
function thresholdPass(absPct, samples, settings) {
  if (samples < settings.minSamplesPerCell) return false;
  if (absPct <= settings.correctionDeadbandPct || absPct >= settings.extremeCorrectionPct) return false;
  if (absPct >= 7) return samples > 10;
  if (absPct > settings.correctionDeadbandPct) return samples > 15;
  return false;
}

export function correctionToSafetyBand(errorPct, deadbandPct=3) {
  if(!Number.isFinite(errorPct)||!Number.isFinite(deadbandPct)||deadbandPct<0||Math.abs(errorPct)<=deadbandPct)return 0;
  const target=Math.sign(errorPct)*deadbandPct;
  return ((1+errorPct/100)/(1+target/100)-1)*100;
}

function quantizeSuggestion(value, settings) {
  const step=Math.abs(settings.suggestionStepPct);
  const limit=Math.abs(settings.maxSuggestionPct);
  if (!Number.isFinite(value) || !Number.isFinite(step) || step<=0 || !Number.isFinite(limit) || limit<step) return 0;
  const units=Math.min(Math.floor(limit/step+1e-9),Math.round(Math.abs(value)/step));
  return Math.sign(value)*units*step;
}

function confidenceFor(cell, settings) {
  if(cell.effectiveN<settings.minMediumEffectiveN)return 'Low';
  let score = 0;
  if (cell.effectiveN >= 60) score += 3;
  else if (cell.effectiveN >= settings.highConfidenceMinSamples) score += 2;
  else if (cell.effectiveN > 20) score += 1;

  if (cell.effectiveSeconds >= 5) score += 2;
  else if (cell.effectiveSeconds >= 2) score += 1;

  if (cell.segments >= 4) score += 2;
  else if (cell.segments >= 2) score += 1;

  if (cell.consistency === 'Consistent') score += 2;
  else if (cell.consistency === 'Single log') score += 1;

  if (cell.afrStdDev != null && cell.afrStdDev <= 0.30) score += 1;
  if (cell.weightedMadPct != null && cell.weightedMadPct <= 8) score += 1;
  if (cell.directionConsistency >= 0.7) score += 1;
  // High is never assigned below 30 cadence-aware effective samples.
  if (cell.effectiveN >= settings.highConfidenceMinSamples && score >= 8) return 'High';
  if (score >= 4) return 'Medium';
  return 'Low';
}

function correctionStats(rows, settings) {
  const useFuelCl=settings.fuelClMode!=='off';
  const valid = rows.filter(r => Number.isFinite(r.afrActual) && Number.isFinite(r.afrTarget) && r.afrTarget > 0 &&
    (!useFuelCl || fuelClFactor(r.fuelCL,settings.fuelClMode)!=null));
  const errors = valid.map(r => {
    const afrRatio=r.afrActual/r.afrTarget;
    return (fuelClFactor(r.fuelCL,settings.fuelClMode)*afrRatio-1)*100;
  });
  const weights = valid.map(r => temperatureWeight(r.temp));
  const med = median(errors);
  const wmean = weightedMean(errors, weights);
  // Each row is converted to fuel correction first, then robustly combined.
  const robust = (med != null && wmean != null) ? (med+wmean)/2 : (med ?? wmean);
  return {errors, weights, medianCorrection:med, weightedCorrection:wmean, weightedMad:weightedMad(errors,weights), robustCorrection:robust};
}

function platformLabel(platform){return ({android:'Android MX App',apple:'Apple App',unknown:'未標示／通用格式'})[platform]??platform;}

function logPlatform(log){
  const rows=log.rows??log;
  return log.platform??rows.meta?.platform??'unknown';
}

function validatePlatform(logs,requested){
  if(!['auto','apple','android'].includes(requested))throw new Error('Log 系統設定不正確');
  const mismatched=[];
  for(const log of logs){
    const platform=logPlatform(log),name=log.name??(log.rows??log)[0]?.sourceName??'log';
    if(requested==='android'&&platform!=='android')mismatched.push(`${name}（${platformLabel(platform)}）`);
    if(requested==='apple'&&platform==='android')mismatched.push(`${name}（Android MX App）`);
  }
  if(mismatched.length)throw new Error(`Log 系統與檔案內容不一致：${mismatched.join('、')}`);
}

export function analyzeLogs(logs, userSettings={}) {
  const settings = {...DEFAULT_SETTINGS, ...userSettings};
  if(!Array.isArray(logs)||!logs.length)throw new Error('請先匯入至少一個 Log');
  validatePlatform(logs,settings.logPlatform);
  if (!Number.isInteger(settings.minSamplesPerCell) || settings.minSamplesPerCell < 1 || settings.minSamplesPerCell > 500) {
    throw new Error('每格最少有效樣本數必須是 1～500 的整數');
  }
  if(!Number.isFinite(settings.minEngineTemp)||settings.minEngineTemp<-40||settings.minEngineTemp>150)throw new Error('引擎最低溫度必須介於 -40～150°C');
  for(const [label,value] of [['進格等待',settings.entryWaitSeconds],['等待後最少有效秒數',settings.minStableSecondsAfterWait],['加速補油排除秒數',settings.accExclusionSeconds]]){
    if(!Number.isFinite(value)||value<0||value>30)throw new Error(`${label}必須介於 0～30 秒`);
  }
  if(!Number.isFinite(settings.maxSuggestionPct)||settings.maxSuggestionPct<=0||settings.maxSuggestionPct>20)throw new Error('單次最大建議必須介於 0～20%');
  if(!Number.isFinite(settings.correctionDeadbandPct)||settings.correctionDeadbandPct<0||settings.correctionDeadbandPct>=settings.extremeCorrectionPct)throw new Error('修正安全帶設定不正確');
  if(!Number.isFinite(settings.extremeCorrectionPct)||settings.extremeCorrectionPct>50)throw new Error('極端偏差門檻設定不正確');
  if(!Number.isFinite(settings.maxContinuityGapSeconds)||settings.maxContinuityGapSeconds<0.05||settings.maxContinuityGapSeconds>5)throw new Error('連續資料間隔設定不正確');
  if (!['off','positive_adds'].includes(settings.fuelClMode)) {
    throw new Error('Fuel_CL 模式設定不正確');
  }
  const fuelClStates=logs.map(log=>{
    const rows=log.rows??log;
    const values=rows.map(row=>row.fuelCL).filter(Number.isFinite);
    return {name:log.name??rows[0]?.sourceName??'log',hasValues:values.length>0,hasNonZero:values.some(value=>Math.abs(value)>settings.fuelClStateEpsilon)};
  });
  if (settings.fuelClMode!=='off') {
    const missingLogs=fuelClStates.filter(state=>!state.hasValues||!state.hasNonZero).map(state=>state.name);
    if (missingLogs.length) throw new Error(`已選擇納入 Fuel_CL，但下列 Log 沒有非零 Fuel_CL，可能未開啟閉迴路：${missingLogs.join('、')}`);
  } else {
    const activeLogs=fuelClStates.filter(state=>state.hasNonZero).map(state=>state.name);
    if(activeLogs.length)throw new Error(`已選擇不納入 Fuel_CL，但下列 Log 偵測到非零 Fuel_CL：${activeLogs.join('、')}。請確認閉迴路狀態並改選「納入」。`);
  }
  const profile = getEcuProfile(settings.ecuModel);
  const exclusions = {
    engine_temp:0, afr_missing:0, wbo2_range:0, wbo2_not_ready:0,
    fuel_cut:0, after_acc_fuel:0, fuel_cl_missing:0, fuel_cl_range:0,
    out_of_axis:0, entry_wait:0, short_segment:0
  };
  const segments = [];
  const anomalies = [];
  const diagnostics = {logs:logs.length, rawRows:0, tempPass:0, afrPass:0, accelPass:0, gatePass:0, afterEntryWait:0, acceptedSamples:0};

  for (const log of logs) {
    const rows = log.rows ?? log;
    diagnostics.rawRows += rows.length;
    const sourceName = log.name ?? rows[0]?.sourceName ?? 'log';
    let lastAccTime = null;
    let current = null;

    const flush = () => {
      if (!current) return;
      const usableDuration = current.rows.length ? current.rows.reduce((s,x)=>s+x.dt,0) : 0;
      if (usableDuration + 1e-9 < settings.minStableSecondsAfterWait) {
        exclusions.short_segment += current.rows.length;
      } else if (current.rows.length) {
        segments.push({...current, duration: usableDuration, sourceName});
      }
      current = null;
    };

    for (let i=0; i<rows.length; i++) {
      const row = rows[i];
      if(i>0&&row.time-rows[i-1].time>settings.maxContinuityGapSeconds)flush();
      if (row.temp != null && row.temp >= settings.minEngineTemp) diagnostics.tempPass++;
      if (row.temp != null && row.temp >= settings.minEngineTemp && row.afrTarget != null && row.afrActual != null &&
          row.afrActual >= settings.minAfr && row.afrActual <= settings.maxAfr && row.wbo2Ready !== false) diagnostics.afrPass++;

      // MiniX baseline is zero. A non-zero multiplier marks acceleration enrichment.
      const accActive = row.accFuel != null && Math.abs(row.accFuel) > settings.accFuelTolerance;
      if (accActive) lastAccTime = row.time;
      if (!accActive) diagnostics.accelPass++;

      const gate = qualityGate(row, settings, lastAccTime);
      if (gate) { exclusions[gate]++; flush(); continue; }
      diagnostics.gatePass++;

      const tpsBin = nearestAxisInRange(row.tps, profile.fuelTpsAxis);
      const rpmBin = nearestAxisInRange(row.rpm, profile.fuelRpmAxis);
      if (tpsBin==null || rpmBin==null) { exclusions.out_of_axis++; flush(); continue; }
      const key = `${tpsBin}|${rpmBin}`;
      if (!current || current.key !== key) {
        flush();
        current = { key, tps:tpsBin, rpm:rpmBin, enteredAt:row.time, rows:[] };
      }
      const sinceEntry = row.time - current.enteredAt;
      if (sinceEntry + 1e-9 < settings.entryWaitSeconds) {
        exclusions.entry_wait++;
        continue;
      }
      diagnostics.afterEntryWait++;
      current.rows.push({row, dt:rowInterval(rows,i,settings.maxContinuityGapSeconds)});
    }
    flush();
  }

  const byCell = new Map();
  for (const seg of segments) {
    if (!byCell.has(seg.key)) byCell.set(seg.key, []);
    byCell.get(seg.key).push(seg);
  }

  diagnostics.acceptedSamples = segments.reduce((n,s)=>n+s.rows.length,0);

  const cells = [];
  for (const [key, segs] of byCell) {
    const accepted = segs.flatMap(s=>s.rows);
    const rows = accepted.map(x=>x.row);
    const actuals = rows.map(r=>r.afrActual).filter(Number.isFinite);
    const targets = rows.map(r=>r.afrTarget).filter(Number.isFinite);
    const temps = rows.map(r=>r.temp).filter(Number.isFinite);
    const actualMedian = median(actuals), targetMedian = median(targets);
    const afrStats = correctionStats(rows,{...settings,fuelClMode:'off'});
    const stats = correctionStats(rows,settings);
    const theoretical = stats.robustCorrection;
    const effectiveN=accepted.reduce((sum,x)=>sum+Math.min(1,x.dt/0.1)*Math.min(1,temperatureWeight(x.row.temp)/1.5),0);

    const actualWeighted = weightedMean(actuals, rows.filter(r=>Number.isFinite(r.afrActual)).map(r=>temperatureWeight(r.temp)));
    const targetWeighted = weightedMean(targets, rows.filter(r=>Number.isFinite(r.afrTarget)).map(r=>temperatureWeight(r.temp)));

    const perLog = new Map();
    for (const s of segs) {
      if (!perLog.has(s.sourceName)) perLog.set(s.sourceName, []);
      perLog.get(s.sourceName).push(...s.rows.map(x=>x.row));
    }
    const logCorrections = [...perLog.entries()].map(([name, rs]) => {
      const st = correctionStats(rs,settings);
      return {name, correctionPct:st.robustCorrection, samples:rs.length};
    }).filter(x=>x.correctionPct != null);

    let consistency = 'Single log';
    if (logCorrections.length > 1) {
      const signs = new Set(logCorrections.filter(x=>Math.abs(x.correctionPct)>=0.5).map(x=>Math.sign(x.correctionPct)));
      const vals = logCorrections.map(x=>x.correctionPct);
      const spread = Math.max(...vals) - Math.min(...vals);
      consistency = signs.size <= 1 && spread <= 3 ? 'Consistent' : 'Mixed';
    }

    const segmentCorrections=segs.map(seg=>correctionStats(seg.rows.map(x=>x.row),settings).robustCorrection).filter(Number.isFinite);
    const directional=segmentCorrections.filter(value=>Math.abs(value)>settings.correctionDeadbandPct);
    const positive=directional.filter(value=>value>0).length,negative=directional.filter(value=>value<0).length;
    const directionConsistency=directional.length?Math.max(positive,negative)/directional.length:1;

    const fuelClValues=rows.map(r=>r.fuelCL).filter(Number.isFinite);
    const fuelClMedian = median(fuelClValues);
    const fuelClMaxAbs=fuelClValues.length?fuelClValues.reduce((m,v)=>Math.max(m,Math.abs(v)),0):null;
    const fuelClIncluded=settings.fuelClMode!=='off';

    const safetyBandCorrection=correctionToSafetyBand(theoretical,settings.correctionDeadbandPct);
    let suggestion = 0, status = 'Monitor';
    if (theoretical != null && thresholdPass(Math.abs(theoretical), rows.length, settings)) {
      suggestion = quantizeSuggestion(safetyBandCorrection, settings);
      status = suggestion===0?'Monitor':'Adjust';
    }
    const [tps,rpm] = key.split('|').map(Number);
    if (consistency === 'Mixed') { status = 'Verify'; suggestion = 0; }
    if (fuelClIncluded && fuelClMaxAbs>settings.fuelClSafetyThreshold) { status = 'Verify'; suggestion = 0; }
    if (Math.abs(theoretical??0)>=settings.extremeCorrectionPct) { status='Verify'; suggestion=0; }
    if ((stats.weightedMad??0)>8 || directionConsistency<0.7) { status='Verify'; suggestion=0; }

    const cell = {
      tps, rpm,
      targetAfrMedian: round(targetMedian,3),
      targetAfrWeighted: round(targetWeighted,3),
      actualAfrMedian: round(actualMedian,3),
      actualAfrWeighted: round(actualWeighted,3),
      actualAfrMean: round(mean(actuals),3),
      afrStdDev: round(stddev(actuals),3),
      tempMedian: round(median(temps),1),
      tempWeightedShare90to100: round(
        rows.length ? rows.filter(r=>Number.isFinite(r.temp) && r.temp>=90 && r.temp<=100).length/rows.length*100 : 0, 1
      ),
      fuelClMedian: round(fuelClMedian,2),
      fuelClMin: round(fuelClValues.length?fuelClValues.reduce((m,v)=>Math.min(m,v),Infinity):null,2),
      fuelClMax: round(fuelClValues.length?fuelClValues.reduce((m,v)=>Math.max(m,v),-Infinity):null,2),
      fuelClIncluded,
      mapMedian: round(median(rows.map(r=>r.map).filter(Number.isFinite)),2),
      fuelPwMedian: round(median(rows.map(r=>r.fuelPW).filter(Number.isFinite)),3),
      finalVmMedian: round(median(rows.map(r=>r.finalVM).filter(Number.isFinite)),3),
      saMedian: round(median(rows.map(r=>r.sa).filter(Number.isFinite)),2),
      samples: rows.length,
      effectiveN:round(effectiveN,1),
      effectiveSeconds: round(segs.reduce((s,x)=>s+x.duration,0),2),
      segments: segs.length,
      medianCorrectionPct: round(stats.medianCorrection,2),
      weightedCorrectionPct: round(stats.weightedCorrection,2),
      weightedMadPct:round(stats.weightedMad,2),
      directionConsistency:round(directionConsistency,2),
      afrResidualCorrectionPct: round(afrStats.robustCorrection,2),
      theoreticalCorrectionPct: round(theoretical,2),
      safetyBandCorrectionPct:round(safetyBandCorrection,2),
      suggestedCorrectionPct: round(suggestion,2),
      consistency,
      status,
      logCorrections: logCorrections.map(x=>({...x, correctionPct:round(x.correctionPct,2)}))
    };
    cell.confidence = confidenceFor(cell, settings);
    if (cell.confidence === 'Low' && cell.status === 'Adjust') {
      cell.status = 'Monitor';
      cell.suggestedCorrectionPct = 0;
    }
    cells.push(cell);

    if (Math.abs(theoretical ?? 0) >= settings.extremeCorrectionPct || consistency === 'Mixed' ||
        (fuelClIncluded && fuelClMaxAbs>settings.fuelClSafetyThreshold)) {
      const type = consistency === 'Mixed' ? 'multi_log_mismatch'
        : fuelClIncluded && fuelClMaxAbs>settings.fuelClSafetyThreshold ? 'fuel_cl_safety_limit'
        : 'extreme_correction';
      anomalies.push({type, tps, rpm, value:round(theoretical,2), fuelClMedian:round(fuelClMedian,2)});
    }
  }

  cells.sort((a,b)=>a.tps-b.tps || a.rpm-b.rpm);
  return {
    preset: PRESET.name,
    algorithmVersion: 'V4.4',
    settings,
    calculationMode:fuelClModeLabel(settings.fuelClMode),
    platformSummary:[...new Set(logs.map(log=>platformLabel(logPlatform(log))))],
    grid: {fuel:profile.fuelGrid, ignition:profile.ignitionGrid, variableAxes:profile.variableAxes, axisVerified:!profile.variableAxes},
    axes: {fuelRpmAxis:profile.fuelRpmAxis, fuelTpsAxis:profile.fuelTpsAxis},
    cells,
    exclusions,
    segments: segments.length,
    anomalies,
    diagnostics,
    summary: {
      cells: cells.length,
      adjustCells: cells.filter(c=>c.status==='Adjust').length,
      verifyCells: cells.filter(c=>c.status==='Verify').length,
      highConfidenceCells: cells.filter(c=>c.confidence==='High').length,
      mediumConfidenceCells: cells.filter(c=>c.confidence==='Medium').length,
      totalSamples: cells.reduce((s,c)=>s+c.samples,0),
      effectiveSeconds: round(cells.reduce((s,c)=>s+c.effectiveSeconds,0),2)
    }
  };
}

export function analyzeIgnition(logs, userSettings={}) {
  const settings = {...DEFAULT_SETTINGS, ...userSettings};
  const profile = getEcuProfile(settings.ecuModel);
  const byCell = new Map();
  let inputRows=0, acceptedRows=0, acceptedMapRows=0;
  const exclusions={missingSa:0,engineTemp:0,fuelCut:0,outOfAxis:0};

  for (const log of logs) {
    const rows = log.rows ?? log;
    inputRows += rows.length;
    const timeDiffs=[];
    for(let i=0;i<rows.length-1;i++){
      const dt=rows[i+1].time-rows[i].time;
      if(Number.isFinite(dt)&&dt>0) timeDiffs.push(dt);
    }
    const cadence=median(timeDiffs);
    const maxInterval=Number.isFinite(cadence)?cadence*3:0;
    for (let i=0;i<rows.length;i++) {
      const row=rows[i];
      if (!Number.isFinite(row.sa)) { exclusions.missingSa++; continue; }
      if (!Number.isFinite(row.temp) || row.temp < settings.minEngineTemp) { exclusions.engineTemp++; continue; }
      if (row.fuelPW!=null && row.fuelPW<=0.001) { exclusions.fuelCut++; continue; }
      const tps=nearestAxisInRange(row.tps,profile.ignitionTpsAxis);
      const rpm=nearestAxisInRange(row.rpm,profile.ignitionRpmAxis);
      if (tps==null || rpm==null) { exclusions.outOfAxis++; continue; }
      const key=`${tps}|${rpm}`;
      if (!byCell.has(key)) byCell.set(key,[]);
      const rawDt=i<rows.length-1?Math.max(0,rows[i+1].time-row.time):0;
      const dt=maxInterval>0?Math.min(rawDt,maxInterval):0;
      byCell.get(key).push({sa:row.sa,map:row.map,dt});
      acceptedRows++;
      if(Number.isFinite(row.map))acceptedMapRows++;
    }
  }

  const cells=[...byCell.entries()].map(([key,values])=>{
    const [tps,rpm]=key.split('|').map(Number);
    const angles=values.map(x=>x.sa);
    const pressures=values.map(x=>x.map).filter(Number.isFinite);
    return {
      tps,rpm,
      actualSaMedian:round(median(angles),2),
      actualSaMean:round(mean(angles),2),
      actualSaMin:round(angles.reduce((m,v)=>Math.min(m,v),Infinity),2),
      actualSaMax:round(angles.reduce((m,v)=>Math.max(m,v),-Infinity),2),
      actualSaStdDev:round(stddev(angles),2),
      mapMedian:round(median(pressures),2),
      mapMean:round(mean(pressures),2),
      mapMin:pressures.length?round(pressures.reduce((m,v)=>Math.min(m,v),Infinity),2):null,
      mapMax:pressures.length?round(pressures.reduce((m,v)=>Math.max(m,v),-Infinity),2):null,
      mapStdDev:round(stddev(pressures),2),
      mapSamples:pressures.length,
      samples:angles.length,
      effectiveSeconds:round(values.reduce((sum,x)=>sum+x.dt,0),2)
    };
  }).sort((a,b)=>a.tps-b.tps||a.rpm-b.rpm);

  return {
    settings,
    grid:profile.ignitionGrid,
    variableAxes:profile.variableAxes,
    axes:{rpmAxis:profile.ignitionRpmAxis,tpsAxis:profile.ignitionTpsAxis},
    cells,
    summary:{
      inputRows,acceptedRows,acceptedMapRows,cells:cells.length,
      cellsWithMap:cells.filter(c=>c.mapSamples>0).length,
      exclusions
    }
  };
}

export function reportToCsv(report) {
  const cols = [
    'ECU Model','Log platform','Fuel_CL mode','Minimum samples per cell','TPS','RPM','Target AFR median','Target AFR weighted','Actual AFR median','Actual AFR weighted',
    'Samples','Effective N','Effective sec','Segments','Temp median','90-100C share %','MAP','FuelPW','Final_VM','SA',
    'AFR residual correction %','Median fuel correction %','Temp-weighted fuel correction %','V4.4 fuel correction %','Weighted MAD %','Direction consistency','Correction to 3% safety band %','Suggested %',
    'Fuel_CL raw median','Fuel_CL raw min','Fuel_CL raw max','Fuel_CL included','Confidence','Consistency','Status'
  ];
  const rows = report.cells.map(c => [
    report.settings.ecuModel,report.platformSummary.join(' + '),report.calculationMode,report.settings.minSamplesPerCell,c.tps,c.rpm,c.targetAfrMedian,c.targetAfrWeighted,c.actualAfrMedian,c.actualAfrWeighted,
    c.samples,c.effectiveN,c.effectiveSeconds,c.segments,c.tempMedian,c.tempWeightedShare90to100,c.mapMedian,c.fuelPwMedian,c.finalVmMedian,c.saMedian,
    c.afrResidualCorrectionPct,c.medianCorrectionPct,c.weightedCorrectionPct,c.theoreticalCorrectionPct,c.weightedMadPct,c.directionConsistency,c.safetyBandCorrectionPct,c.suggestedCorrectionPct,
    c.fuelClMedian,c.fuelClMin,c.fuelClMax,c.fuelClIncluded,c.confidence,c.consistency,c.status
  ]);
  return [cols,...rows].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
}

export function compareReports(beforeReport,afterReport) {
  const beforeBy=new Map(beforeReport.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  const afterBy=new Map(afterReport.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  const keys=new Set([...beforeBy.keys(),...afterBy.keys()]);
  const cells=[...keys].map(key=>{
    const before=beforeBy.get(key)??null;
    const after=afterBy.get(key)??null;
    const [tps,rpm]=key.split('|').map(Number);
    const beforeError=before?.theoreticalCorrectionPct??null;
    const afterError=after?.theoreticalCorrectionPct??null;
    const absoluteErrorChange=beforeError!=null&&afterError!=null
      ? Math.abs(afterError)-Math.abs(beforeError):null;
    let result='Only one side';
    if (absoluteErrorChange!=null) {
      const confidenceOk=before.confidence!=='Low'&&after.confidence!=='Low';
      const reversed=Math.sign(beforeError)!==0&&Math.sign(afterError)!==0&&Math.sign(beforeError)!==Math.sign(afterError);
      if(!confidenceOk)result='Low confidence';
      else if(reversed&&Math.abs(afterError)>afterReport.settings.correctionDeadbandPct)result='Overcorrected';
      else if(Math.abs(afterError)<=afterReport.settings.correctionDeadbandPct)result='Improved';
      else result=absoluteErrorChange<=-0.5?'Improved':absoluteErrorChange>=0.5?'Worse':'Similar';
    }
    return {
      tps,rpm,
      beforeTargetAfr:before?.targetAfrMedian??null,
      afterTargetAfr:after?.targetAfrMedian??null,
      beforeActualAfr:before?.actualAfrMedian??null,
      afterActualAfr:after?.actualAfrMedian??null,
      beforeCorrectionPct:beforeError,
      afterCorrectionPct:afterError,
      correctionChangePct:beforeError!=null&&afterError!=null?round(afterError-beforeError,2):null,
      absoluteErrorChangePct:round(absoluteErrorChange,2),
      beforeSamples:before?.samples??0,
      afterSamples:after?.samples??0,
      beforeConfidence:before?.confidence??null,
      afterConfidence:after?.confidence??null,
      result
    };
  }).sort((a,b)=>a.tps-b.tps||a.rpm-b.rpm);
  return {
    before:beforeReport,
    after:afterReport,
    axes:beforeReport.axes,
    cells,
    summary:{
      comparable:cells.filter(c=>c.absoluteErrorChangePct!=null).length,
      improved:cells.filter(c=>c.result==='Improved').length,
      worse:cells.filter(c=>c.result==='Worse').length,
      similar:cells.filter(c=>c.result==='Similar').length,
      overcorrected:cells.filter(c=>c.result==='Overcorrected').length,
      lowConfidence:cells.filter(c=>c.result==='Low confidence').length,
      onlyOneSide:cells.filter(c=>c.result==='Only one side').length
    }
  };
}

export function comparisonToCsv(comparison) {
  const cols=['TPS','RPM','Before target AFR','After target AFR','Before actual AFR','After actual AFR',
    'Before fuel correction %','After fuel correction %','Correction change %','Absolute error change %',
    'Before samples','After samples','Before confidence','After confidence','Result'];
  const rows=comparison.cells.map(c=>[c.tps,c.rpm,c.beforeTargetAfr,c.afterTargetAfr,c.beforeActualAfr,c.afterActualAfr,
    c.beforeCorrectionPct,c.afterCorrectionPct,c.correctionChangePct,c.absoluteErrorChangePct,
    c.beforeSamples,c.afterSamples,c.beforeConfidence,c.afterConfidence,c.result]);
  return [cols,...rows].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
}

export function ignitionToCsv(report) {
  const cols=['ECU Model','TPS','RPM','Actual SA median','Actual SA mean','Actual SA min','Actual SA max','SA stddev',
    'Manifold absolute pressure median','Manifold absolute pressure mean','Manifold absolute pressure min','Manifold absolute pressure max','Manifold pressure stddev','MAP samples',
    'Samples','Effective sec'];
  const rows=report.cells.map(c=>[
    report.settings.ecuModel,c.tps,c.rpm,c.actualSaMedian,c.actualSaMean,c.actualSaMin,c.actualSaMax,c.actualSaStdDev,
    c.mapMedian,c.mapMean,c.mapMin,c.mapMax,c.mapStdDev,c.mapSamples,c.samples,c.effectiveSeconds
  ]);
  return [cols,...rows].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
}
